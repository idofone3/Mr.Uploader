#!/usr/bin/env python3
"""
DeepSeek Wrapper - simplest, most robust OpenAI-compatible API for OpenCode.

Architecture (unchanged, extended):
  * Playwright worker pool with persistent Chromium profiles (``pool_workers/worker_N``).
  * Per-conversation session -> worker pinning so a DeepSeek web chat keeps its
    context (and its WAF/PoW cookies).
  * DeepSeek's chat UI is scraped from the DOM; the "DeepThink" reasoning panel
    is captured separately from the final answer.

OpenCode compatibility - what the client on the other side actually enforces
--------------------------------------------------------------------------
OpenCode drives a custom provider through ``npm: "@ai-sdk/openai-compatible"``
(https://opencode.ai/docs/providers/). That package talks **only** to
``POST {baseURL}/chat/completions`` and never falls back to ``/v1/responses``
(``packages/openai-compatible/src/chat/openai-compatible-chat-language-model.ts``
builds ``url({path: '/chat/completions'})``); so the Responses API is out of scope.

Every SSE ``data:`` line is JSON-parsed and validated against ``chunkBaseSchema``
in that same file. The schema is a ``z.looseObject`` that:

  * **requires** a top-level ``choices`` array (unknown extra keys are allowed,
    a frame *without* ``choices`` is rejected and surfaces as an ``error`` part);
  * allows ``id`` / ``created`` / ``model`` to be absent or null;
  * allows ``delta`` to be absent, but if present only these keys are read:
    ``role`` (enum ``'assistant' | ''`` - sending ``'user'`` fails validation),
    ``content`` (string or parts array), ``reasoning_content`` (string),
    ``reasoning`` (string), ``tool_calls`` (array);
  * requires every ``delta.tool_calls[i]`` element to have a ``function``
    object, even if it is empty;
  * accepts ``usage.completion_tokens_details.reasoning_tokens``.

``parseJsonEventStream`` (``packages/provider-utils/src/parse-json-event-stream.ts``)
ignores ``data: [DONE]`` and tolerates malformed frames by emitting an error
*part*, but we never emit one: every frame below is schema-valid.

Tool calls stream in the OpenAI shape: a first chunk that carries
``index``/``id``/``function.name`` (the shared ``StreamingToolCallTracker``
rejects a first delta without a name), then argument fragments, then a chunk
with ``finish_reason: "tool_calls"``.

Reasoning survives multi-turn replay because
``convertToOpenAICompatibleChatMessages`` puts captured thinking back on the
assistant message as ``reasoning_content``; this server renders that field into
the prompt instead of dropping it.
"""
from __future__ import annotations

import asyncio
import contextlib
import hashlib
import hmac
import json
import os
import re
import time
import uuid
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any, AsyncIterator, Dict, List, Optional, Tuple

import uvicorn
from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import (
    JSONResponse,
    PlainTextResponse,
    StreamingResponse,
)
from playwright.async_api import async_playwright
from pydantic import BaseModel, ConfigDict, Field

try:  # optional hardening; the pool still works without it
    from playwright_stealth import Stealth

    _STEALTH: Optional[Any] = Stealth()
except Exception:  # pragma: no cover - optional dependency
    _STEALTH = None

# --------------------------------------------------------------------------- #
# configuration
# --------------------------------------------------------------------------- #
BASE_DIR = Path(__file__).resolve().parent
WORKERS_DIR = BASE_DIR / "pool_workers"
WORKERS_DIR.mkdir(exist_ok=True)
TOKEN_PATH = BASE_DIR / "deepseek_user_token.txt"
# Optional Netscape-format cookie file (e.g. a valid aws-waf-token) seeded into
# every worker before the first navigation, so boots do not stall on the WAF.
COOKIE_PATH = BASE_DIR / "deepseek_cookies.txt"

POOL_SIZE = int(os.environ.get("DS_POOL_SIZE", "2"))
# Bind to loopback by default: the API is unauthenticated unless DS_API_KEY is
# set, and /debug/* can dump live chat HTML. Opt into 0.0.0.0 deliberately.
HOST = os.environ.get("DS_POOL_HOST", "127.0.0.1")
PORT = int(os.environ.get("DS_POOL_PORT", "8000"))
HEADLESS = os.environ.get("DS_HEADLESS", "1") == "1"
# Optional shared secret. When set, every endpoint except /, /health and the
# OpenAPI docs requires `Authorization: Bearer <key>` (what OpenCode sends for
# the configured apiKey) or `x-api-key: <key>`.
API_KEY = os.environ.get("DS_API_KEY", "").strip()

# Boot budget for the whole pool, and how long a request waits for a worker.
BOOT_TIMEOUT = float(os.environ.get("DS_BOOT_TIMEOUT", "120"))
LEASE_TIMEOUT = float(os.environ.get("DS_LEASE_TIMEOUT", "180"))
FIRST_TOKEN_TIMEOUT = float(os.environ.get("DS_FIRST_TOKEN_TIMEOUT", "90"))
STREAM_TIMEOUT = float(os.environ.get("DS_STREAM_TIMEOUT", "600"))
POLL_TICK = float(os.environ.get("DS_POLL_TICK", "0.35"))
STABLE_TICKS = int(os.environ.get("DS_STABLE_TICKS", "6"))
# How long the text may stay unchanged while the UI *still* looks busy before
# the turn is declared finished. DeepSeek's web-search UI keeps a stop/busy
# control alive well after the answer stops changing, so without a cap a
# searched reply would never be returned.
BUSY_GRACE = float(os.environ.get("DS_BUSY_GRACE", "20"))
# Budget for clearing a DeepSeek conversation before giving up on the tab.
RESET_TIMEOUT = float(os.environ.get("DS_RESET_TIMEOUT", "9"))

VERSION = "6.1"
DEEPSEEK_URL = "https://chat.deepseek.com/"
# One model. The web UI is a single assistant; thinking is always armed and
# web search is chosen per request via the `web_search` flag.
MODEL_IDS = ("deepseek",)
# Legacy ids accepted for backward compatibility and mapped to "deepseek".
MODEL_ALIASES = {
    "deepseek-chat": "deepseek",
    "deepseek-reasoner": "deepseek",
    "deepseek-coder": "deepseek",
    "deepseek-search": "deepseek",
}

HAR_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/140.0.0.0 Safari/537.36"
)

SEL_TEXTAREA = "textarea"
# The sidebar control is a bare `div[tabindex="0"]` - it has no role=button -
# so a role-based selector matches nothing and every "reset" silently no-ops.
SEL_NEW_CHAT = (
    'div[tabindex="0"]:has-text("New chat"), '
    'div[role="button"]:has-text("New chat"), '
    'button:has-text("New chat"), '
    'a:has-text("New chat"), '
    'span:text-is("New chat")'
)
# Composer toolbar toggle, verified against the live DeepSeek DOM:
#   <div aria-pressed="false" class="ds-toggle-button">
#     <span>DeepThink</span>
#   </div>
SEL_DEEP_THINK = 'div.ds-toggle-button:has-text("DeepThink")'
# Sibling toggle in the same composer toolbar; arms DeepSeek's web browsing.
SEL_SEARCH = 'div.ds-toggle-button:has-text("Search")'
# Class DeepSeek puts on the *answer* markdown block (as opposed to the
# thinking block, which is a bare .ds-markdown).
ANSWER_MARKER = "ds-assistant-message-main-content"

# --------------------------------------------------------------------------- #
# OpenAI-compatible schemas
# --------------------------------------------------------------------------- #
class ErrorDetail(BaseModel):
    """The body of every non-2xx response, mirroring OpenAI's error envelope."""

    message: str
    type: str = "invalid_request_error"
    param: Optional[str] = None
    code: Optional[str] = None


class ErrorResponse(BaseModel):
    """Structured error returned instead of a bare 500."""

    error: ErrorDetail


class FunctionCall(BaseModel):
    name: str
    arguments: Optional[str] = None


class ToolCall(BaseModel):
    id: str
    type: str = "function"
    function: FunctionCall


class Message(BaseModel):
    """One input message.

    ``reasoning_content`` is included on purpose: OpenCode replays captured
    thinking on the assistant message, and dropping it would lose context.
    """

    model_config = ConfigDict(extra="allow")

    role: str = Field(..., description="system | user | assistant | tool | developer")
    content: Optional[Any] = Field(
        None, description="A string, or an array of OpenAI content parts."
    )
    reasoning_content: Optional[str] = Field(
        None, description="Captured DeepThink/reasoning text from a previous turn."
    )
    tool_calls: Optional[List[Dict[str, Any]]] = None
    tool_call_id: Optional[str] = None
    name: Optional[str] = None


class FunctionDef(BaseModel):
    name: str
    description: Optional[str] = None
    parameters: Optional[Dict[str, Any]] = Field(
        None, description="JSON Schema for the function arguments."
    )


class Tool(BaseModel):
    type: str = "function"
    function: FunctionDef


class StreamOptions(BaseModel):
    model_config = ConfigDict(extra="allow")
    include_usage: Optional[bool] = None


class ChatRequest(BaseModel):
    """OpenAI Chat Completions request, extended with pool controls."""

    model_config = ConfigDict(
        extra="allow",
        json_schema_extra={
            "example": {
                "model": "deepseek",
                "messages": [{"role": "user", "content": "Say hello in five words."}],
                "stream": False,
            }
        },
    )

    model: str = Field(
        "deepseek",
        description=(
            'Only "deepseek" exists; older ids like "deepseek-reasoner" are '
            "accepted as aliases and mapped to it."
        ),
    )
    messages: List[Message] = Field(..., min_length=1)
    stream: bool = Field(False, description="Emit `text/event-stream` chunks.")
    temperature: Optional[float] = None
    top_p: Optional[float] = None
    max_tokens: Optional[int] = None
    max_completion_tokens: Optional[int] = None
    n: Optional[int] = None
    stop: Optional[Any] = None
    stream_options: Optional[StreamOptions] = None
    tools: Optional[List[Tool]] = Field(
        None, description="Bridged into the prompt; results become tool_calls."
    )
    tool_choice: Optional[Any] = None
    response_format: Optional[Any] = None
    user: Optional[str] = Field(None, description="Used as the session key when set.")
    web_search: Optional[bool] = Field(
        None,
        description=(
            "Arm DeepSeek's web-search switch for this turn. Off by default; "
            "thinking is always on regardless."
        ),
    )
    # pool controls (not part of the OpenAI spec, but harmless extras)
    session_id: Optional[str] = Field(
        None, description="Pin this request to a specific browser worker session."
    )
    reset: bool = Field(
        False, description="Start a fresh DeepSeek chat before sending the prompt."
    )


class PromptTokensDetails(BaseModel):
    cached_tokens: int = 0


class CompletionTokensDetails(BaseModel):
    reasoning_tokens: int = 0
    accepted_prediction_tokens: int = 0
    rejected_prediction_tokens: int = 0


class Usage(BaseModel):
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0
    prompt_tokens_details: Optional[PromptTokensDetails] = None
    completion_tokens_details: Optional[CompletionTokensDetails] = None


class AssistantMessage(BaseModel):
    role: str = "assistant"
    content: Optional[str] = None
    reasoning_content: Optional[str] = None
    tool_calls: Optional[List[ToolCall]] = None
    refusal: Optional[str] = None


class ChatCompletionChoice(BaseModel):
    index: int = 0
    message: AssistantMessage
    finish_reason: Optional[str] = None
    logprobs: Optional[Any] = None


class ChatCompletion(BaseModel):
    """Non-streaming response (``stream: false``)."""

    id: str
    object: str = "chat.completion"
    created: int
    model: str
    choices: List[ChatCompletionChoice]
    usage: Optional[Usage] = None
    system_fingerprint: Optional[str] = "deepseek-web"


class ChunkDelta(BaseModel):
    role: Optional[str] = None
    content: Optional[str] = None
    reasoning_content: Optional[str] = None
    tool_calls: Optional[List[Dict[str, Any]]] = None


class ChunkChoice(BaseModel):
    index: int = 0
    delta: ChunkDelta = Field(default_factory=ChunkDelta)
    finish_reason: Optional[str] = None


class ChatCompletionChunk(BaseModel):
    """One SSE frame. ``choices`` is always present - see module docstring."""

    id: str
    object: str = "chat.completion.chunk"
    created: int
    model: str
    choices: List[ChunkChoice]
    usage: Optional[Usage] = None
    system_fingerprint: Optional[str] = "deepseek-web"


class ModelCard(BaseModel):
    id: str
    object: str = "model"
    created: int
    owned_by: str = "deepseek"


class ModelList(BaseModel):
    object: str = "list"
    data: List[ModelCard]


class RouteInfo(BaseModel):
    method: str
    path: str
    summary: str


class RootResponse(BaseModel):
    name: str
    version: str
    openai_compatible: bool = True
    docs: str
    openapi: str
    routes: List[RouteInfo]


class WorkerStatus(BaseModel):
    id: int
    ready: bool
    busy: bool
    session_id: Optional[str] = None
    last_used: float
    error: Optional[str] = None


class HealthResponse(BaseModel):
    ready: bool
    version: str
    pool_size: int
    free: int
    workers_ready: int
    sessions: List[str]
    workers: List[WorkerStatus]


class SessionDeleted(BaseModel):
    deleted: str


class SessionReset(BaseModel):
    reset: str


class SelectorMatch(BaseModel):
    selector: str
    count: int
    snippet: Optional[str] = None


class SelectorReport(BaseModel):
    session_id: str
    message_count: int
    matches: List[SelectorMatch]


class ExtractDebug(BaseModel):
    session_id: str
    reasoning: str
    content: str
    textarea_present: bool
    generating: bool
    deep_think: Optional[bool] = None
    web_search: Optional[bool] = None


# --------------------------------------------------------------------------- #
# errors
# --------------------------------------------------------------------------- #
class WorkerError(RuntimeError):
    """A recoverable failure inside the browser pool."""

    def __init__(
        self,
        message: str,
        *,
        type: str = "server_error",
        code: str = "worker_error",
        status: int = 503,
    ) -> None:
        super().__init__(message)
        self.type = type
        self.code = code
        self.status = status


# --------------------------------------------------------------------------- #
# prompt construction
# --------------------------------------------------------------------------- #
TOOL_PROTOCOL = """\
You can call tools. When you need a tool, reply with ONLY a fenced code block:

```json
{"tool_calls": [{"name": "<tool_name>", "arguments": {}}]}
```

Rules:
- Emit at most one such JSON block, and no prose around it, when calling a tool.
- `name` must be one of the tools below; never invent a tool.
- `arguments` must be a JSON object matching that tool's parameter schema.
- Use ONLY this JSON form. No XML, no tag-based, no vendor-specific tool syntax.
- If no tool is needed, answer normally in prose and do not emit JSON.
"""


def _text_of(content: Any) -> str:
    """Flatten OpenAI message content (string or parts array) to plain text."""
    if content is None:
        return ""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        out: List[str] = []
        for part in content:
            if isinstance(part, dict):
                if isinstance(part.get("text"), str):
                    out.append(part["text"])
                elif part.get("type") == "image_url":
                    out.append("[image]")
            else:
                out.append(str(part))
        return "".join(out)
    return str(content)


def _render_tool(t: Tool) -> str:
    params = json.dumps(t.function.parameters or {"type": "object"}, ensure_ascii=False)
    desc = (t.function.description or "").strip()
    return f"- {t.function.name}: {desc}\n  parameters: {params}"


def _normalise_tool_calls(raw: Any) -> List[Tuple[str, str]]:
    """Normalise any tool_calls shape into ``[(name, arguments_json), ...]``."""
    out: List[Tuple[str, str]] = []
    if not isinstance(raw, list):
        return out
    for tc in raw:
        if not isinstance(tc, dict):
            continue
        fn = tc.get("function") if isinstance(tc.get("function"), dict) else tc
        name = fn.get("name") or tc.get("name")
        if not name:
            continue
        args = fn.get("arguments", tc.get("arguments", {}))
        if isinstance(args, str):
            args_str = args
        else:
            args_str = json.dumps(args or {}, ensure_ascii=False)
        out.append((str(name), args_str))
    return out


def _messages_to_prompt(
    messages: List[Message],
    tools: Optional[List[Tool]] = None,
    tool_choice: Any = None,
) -> str:
    """Flatten the whole conversation (plus tools) into a single DeepSeek prompt."""
    parts: List[str] = []

    if tools:
        block = [TOOL_PROTOCOL, "", "Available tools:"]
        block.extend(_render_tool(t) for t in tools)
        if tool_choice == "required":
            block.append("\nYou MUST call exactly one tool now.")
        elif tool_choice == "none":
            block.append("\nDo NOT call any tool; answer in prose.")
        elif isinstance(tool_choice, dict):
            wanted = (tool_choice.get("function") or {}).get("name")
            if wanted:
                block.append(f"\nYou MUST call the tool `{wanted}` now.")
        parts.append("System: " + "\n".join(block))

    for m in messages:
        role = (m.role or "").lower()
        content = _text_of(m.content)

        if role in ("system", "developer"):
            if content:
                parts.append("System: " + content)
        elif role == "user":
            label = f"User ({m.name})" if m.name else "User"
            parts.append(f"{label}: {content}")
        elif role == "assistant":
            reasoning = (m.reasoning_content or "").strip()
            if reasoning:
                # Replayed thinking is passed through, never stripped.
                parts.append("Assistant reasoning:\n" + reasoning)
            calls = _normalise_tool_calls(m.tool_calls)
            if calls:
                rendered = [{"name": n, "arguments": a} for n, a in calls]
                parts.append(
                    "Assistant tool_calls: "
                    + json.dumps(rendered, ensure_ascii=False)
                )
            if content:
                parts.append("Assistant: " + content)
        elif role == "tool":
            label = m.name or m.tool_call_id or "tool"
            parts.append(f"Tool result ({label}): {content}")
        else:
            parts.append(f"{role.title() or 'Message'}: {content}")

    return "\n\n".join(p for p in parts if p and p.strip())


# --------------------------------------------------------------------------- #
# tool-call recovery from free-form model output
# --------------------------------------------------------------------------- #
_FENCE_RE = re.compile(r"```(?:json|JSON)?\s*(.+?)```", re.DOTALL)
_XML_RE = re.compile(r"<tool_call>\s*(.+?)\s*</tool_call>", re.DOTALL)

# DeepSeek sometimes answers with its own trained tool-call markup instead of
# the JSON protocol it was asked for. The wrapper tags use U+FF5C (full-width
# vertical bar) around the token below, e.g. open-invoke with name="..." and
# parameter name="..." string="true|false", so parse on the stable ASCII words
# and tolerate whatever the delimiters happen to be.
_DSML_TOKEN = "DSML"
_NATIVE_TAG_RE = re.compile(
    r"<\s*(?P<close>/?)\s*[^<>]*?" + _DSML_TOKEN + r"[^<>]*?(?P<word>invoke|parameter)\b"
    r"(?P<attrs>[^<>]*?)>",
    re.IGNORECASE,
)
_NATIVE_ANY_TAG_RE = re.compile(r"<[^<>]*?" + _DSML_TOKEN + r"[^<>]*?>", re.IGNORECASE)
_ATTR_RE = re.compile(r"""(?P<key>[A-Za-z_][\w-]*)\s*=\s*(?P<quote>["'])(?P<value>.*?)(?P=quote)""")


def _tag_attrs(raw: str) -> Dict[str, str]:
    return {m.group("key").lower(): m.group("value") for m in _ATTR_RE.finditer(raw or "")}


def _extract_native_calls(
    text: str, allowed: set
) -> Tuple[List[Dict[str, Any]], Optional[Tuple[int, int]]]:
    """Parse the model's native tag-based tool calls, if it used them.

    Returns the calls plus the span of text they occupied, so the caller can
    strip the markup out of the visible answer.
    """
    spans = [m.span() for m in _NATIVE_ANY_TAG_RE.finditer(text)]
    if not spans:
        return [], None

    calls: List[Dict[str, Any]] = []
    current: Optional[Dict[str, Any]] = None
    param_name: Optional[str] = None
    param_is_string = True
    param_buf: List[str] = []
    cursor = 0

    for match in _NATIVE_TAG_RE.finditer(text):
        closing = match.group("close") == "/"
        word = (match.group("word") or "").lower()
        attrs = _tag_attrs(match.group("attrs"))
        chunk = text[cursor : match.start()]
        cursor = match.end()
        if param_name is not None:
            param_buf.append(chunk)

        if word == "invoke":
            if current is not None:
                calls.append(current)
                current = None
            param_name = None
            if not closing:
                current = {"name": attrs.get("name", ""), "args": {}}
        elif word == "parameter":
            if closing:
                if current is not None and param_name:
                    value: Any = "".join(param_buf).strip()
                    if not param_is_string:
                        with contextlib.suppress(Exception):
                            value = json.loads(value)
                    current["args"][param_name] = value
            else:
                # `string="false"` lives on the opening tag, so remember it.
                param_name = attrs.get("name")
                param_is_string = attrs.get("string", "true").lower() != "false"
                param_buf = []
    if current is not None:
        calls.append(current)

    out: List[Dict[str, Any]] = []
    for call in calls:
        name = str(call.get("name") or "")
        if not name or (allowed and name not in allowed):
            continue
        out.append(
            {
                "id": f"call_{uuid.uuid4().hex[:12]}",
                "type": "function",
                "function": {
                    "name": name,
                    "arguments": json.dumps(call["args"], ensure_ascii=False),
                },
            }
        )
    if not out:
        return [], None
    return out, (min(s[0] for s in spans), max(s[1] for s in spans))


def _balanced_json_spans(text: str, limit: int = 24) -> List[Tuple[int, int]]:
    """Return spans of brace-balanced ``{...}`` regions found in ``text``."""
    spans: List[Tuple[int, int]] = []
    for start, ch in enumerate(text):
        if ch != "{":
            continue
        if len(spans) >= limit:
            break
        depth = 0
        in_str = False
        escape = False
        for i in range(start, len(text)):
            c = text[i]
            if in_str:
                if escape:
                    escape = False
                elif c == "\\":
                    escape = True
                elif c == '"':
                    in_str = False
                continue
            if c == '"':
                in_str = True
            elif c == "{":
                depth += 1
            elif c == "}":
                depth -= 1
                if depth == 0:
                    spans.append((start, i + 1))
                    break
    return spans


def _payload_to_calls(payload: Any, allowed: set) -> List[Dict[str, Any]]:
    """Convert a decoded JSON payload into OpenAI-shaped tool calls."""
    if isinstance(payload, dict):
        if isinstance(payload.get("tool_calls"), list):
            items = payload["tool_calls"]
        elif "function" in payload and isinstance(payload["function"], dict):
            items = [payload]
        elif "name" in payload or "tool" in payload:
            items = [payload]
        else:
            items = []
    elif isinstance(payload, list):
        items = payload
    else:
        return []

    calls: List[Dict[str, Any]] = []
    for item in items:
        if not isinstance(item, dict):
            continue
        fn = item.get("function") if isinstance(item.get("function"), dict) else item
        name = fn.get("name") or item.get("name") or item.get("tool")
        if not isinstance(name, str) or not name:
            continue
        if allowed and name not in allowed:
            continue
        args = fn.get("arguments")
        if args is None:
            args = item.get("arguments", item.get("parameters", item.get("args", {})))
        if isinstance(args, str):
            args_str = args
        else:
            with contextlib.suppress(Exception):
                args = json.loads(args) if isinstance(args, str) else args
            args_str = json.dumps(args or {}, ensure_ascii=False)
        calls.append(
            {
                "id": str(item.get("id") or f"call_{uuid.uuid4().hex[:12]}"),
                "type": "function",
                "function": {"name": name, "arguments": args_str},
            }
        )
    return calls


def _extract_tool_calls(
    text: str, tools: Optional[List[Tool]]
) -> Tuple[str, Optional[List[Dict[str, Any]]]]:
    """Split ``text`` into (visible content, tool_calls) or (text, None).

    Never raises: anything that does not parse cleanly is left as content so the
    caller can finish with ``finish_reason: "stop"``.
    """
    if not tools or not text:
        return text, None

    allowed = {t.function.name for t in tools if t.function and t.function.name}
    candidates: List[Tuple[int, int, str]] = []
    for m in _FENCE_RE.finditer(text):
        candidates.append((m.start(1), m.end(1), m.group(1)))
    for m in _XML_RE.finditer(text):
        candidates.append((m.start(1), m.end(1), m.group(1)))
    for start, end in _balanced_json_spans(text):
        candidates.append((start, end, text[start:end]))
    candidates.sort(key=lambda c: c[0])
    del candidates[2000:]  # bounded work even on pathological inputs

    # Candidates can be O(len(text)) because _XML_RE matches any substring;
    # only a JSON object/array can ever decode into tool calls, so skip the
    # rest before paying for json.loads.
    for start, end, raw in candidates:
        raw = raw.strip()
        if not raw or raw[0] not in "{[":
            continue
        try:
            payload = json.loads(raw)
        except Exception:
            continue
        calls = _payload_to_calls(payload, allowed)
        if not calls:
            continue
        # Trim the matched region (plus an enclosing fence, if any) out of content.
        cut_start, cut_end = start, end
        fence = _FENCE_RE.search(text, max(0, start - 12))
        if fence and fence.start() <= start and fence.end() >= end:
            cut_start, cut_end = fence.start(), fence.end()
        remaining = (text[:cut_start] + text[cut_end:]).strip()
        return remaining, calls

    native_calls, span = _extract_native_calls(text, allowed)
    if native_calls and span is not None:
        remaining = (text[: span[0]] + text[span[1] :]).strip()
        return remaining, native_calls

    return text, None


# --------------------------------------------------------------------------- #
# DOM scraping helpers
# --------------------------------------------------------------------------- #
# Returns {"reasoning": str, "content": str} for the LAST assistant message.
# Every lookup is defensive: a selector miss returns empty strings, never throws.
# UI chrome that DeepSeek renders *inside* markdown blocks (fenced-code banners,
# Copy/Download buttons, message action buttons). It is hidden around each
# innerText read, then restored, so code blocks and formatting stay intact.
_JS_TEXT_HELPER = r"""
  const norm = (s) => (s || '')
    .replace(/\u00a0/g, ' ')
    .replace(/[ \t]+\n/g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
  // .ds-markdown-cite is an anchor-wrapped superscript reference; its invisible
  // spacer makes innerText read as separate '-1' lines, so it is dropped too.
  const CHROME = '.md-code-block-banner-wrap, .code-info-button-text, .ds-markdown-cite, [role="button"], button, svg, .ds-button';
  const CHROME_LINE = /^\s*(copy|copy code|copy to clipboard|download|复制|下载)\s*$/i;
  function kids(el) { return Array.from(el.childNodes).map(serialize).join(''); }
  function serialize(node) {
    if (!node) return '';
    if (node.nodeType === 3) return node.nodeValue || '';
    if (node.nodeType !== 1) return '';
    if (node.matches && node.matches(CHROME)) return '';
    const tag = (node.tagName || '').toLowerCase();
    if (tag === 'br') return '\n';
    if (tag === 'hr') return '\n\n---\n\n';
    if (tag === 'table') {
      const rows = [];
      for (const tr of node.querySelectorAll('tr')) {
        const cells = [];
        for (const td of tr.children) {
          if (!/^(td|th)$/i.test(td.tagName)) continue;
          cells.push(kids(td).replace(/\s*\n\s*/g, ' ').trim());
        }
        if (cells.length) rows.push(cells);
      }
      if (!rows.length) return '';
      const n = Math.max.apply(null, rows.map(function (r) { return r.length; }));
      const pad = function (r) { const c = r.slice(); while (c.length < n) c.push(''); return c; };
      const lines = ['| ' + pad(rows[0]).join(' | ') + ' |',
                     '| ' + pad(rows[0]).map(function () { return '---'; }).join(' | ') + ' |'];
      for (let i = 1; i < rows.length; i++) lines.push('| ' + pad(rows[i]).join(' | ') + ' |');
      return '\n\n' + lines.join('\n') + '\n\n';
    }
    if (tag === 'pre') {
      const codeEl = node.querySelector('code');
      const raw = ((codeEl ? codeEl.innerText : node.innerText) || '').replace(/\n+$/, '');
      let lang = '';
      const cls = ((codeEl && codeEl.className) || node.className || '');
      const m = /language-([\w+-]+)/.exec(cls);
      if (m) lang = m[1];
      return '\n\n```' + lang + '\n' + raw + '\n```\n\n';
    }
    if (tag === 'code') return '`' + (node.innerText || node.textContent || '') + '`';
    if (tag === 'ul' || tag === 'ol') {
      const items = [];
      let i = 0;
      for (const li of node.children) {
        if (!/^li$/i.test(li.tagName)) continue;
        i++;
        const box = li.querySelector('input[type="checkbox"]');
        const txt = kids(li).replace(/\n+/g, ' ').trim();
        let pre;
        if (box) pre = box.checked ? '- [x] ' : '- [ ] ';
        else pre = (tag === 'ol' ? i + '. ' : '- ');
        items.push(pre + txt);
      }
      return '\n\n' + items.join('\n') + '\n\n';
    }
    if (/^h[1-6]$/.test(tag)) return '\n\n' + '#'.repeat(parseInt(tag[1], 10)) + ' ' + kids(node).trim() + '\n\n';
    if (tag === 'strong' || tag === 'b') return '**' + kids(node) + '**';
    if (tag === 'em' || tag === 'i') return '*' + kids(node) + '*';
    if (tag === 'del' || tag === 's') return '~~' + kids(node) + '~~';
    if (tag === 'a') return '[' + kids(node) + '](' + (node.getAttribute('href') || '') + ')';
    if (tag === 'blockquote') return '\n\n' + kids(node).split('\n').map(function (l) { return '> ' + l; }).join('\n') + '\n\n';
    if (tag === 'p' || tag === 'div' || tag === 'section' || tag === 'article') return '\n\n' + kids(node).trim() + '\n\n';
    return kids(node);
  }
  const textOf = (el) => {
    if (!el) return '';
    const hidden = [];
    for (const n of el.querySelectorAll(CHROME)) {
      hidden.push([n, n.style.display]);
      n.style.display = 'none';
    }
    let raw = '';
    try { raw = serialize(el); }
    finally { for (const pair of hidden) pair[0].style.display = pair[1]; }
    return norm(raw.split('\n').filter((l) => !CHROME_LINE.test(l)).join('\n'));
  };
"""

_EXTRACT_JS = r"""
() => {
""" + _JS_TEXT_HELPER + r"""
  const md = Array.from(document.querySelectorAll('.ds-markdown'));
  if (md.length === 0) return { reasoning: '', content: '' };
  const last = md[md.length - 1];

  const attrBlob = (el) => {
    let cls = '';
    try { if (typeof el.className === 'string') cls = el.className; } catch (e) {}
    return [
      cls,
      el.id || '',
      (el.getAttribute && el.getAttribute('data-testid')) || '',
      (el.getAttribute && el.getAttribute('data-test-id')) || '',
      (el.getAttribute && el.getAttribute('data-role')) || '',
      (el.getAttribute && el.getAttribute('aria-label')) || '',
    ].join(' ').toLowerCase();
  };
  const looksReasoning = (el) => {
    if (!el || el.nodeType !== 1) return false;
    if (/think|reason|\bcot\b|analysis|deepseek-r1/.test(attrBlob(el))) return true;
    const head = norm((el.innerText || '')).slice(0, 26);
    return /^(thought for|thinking|deep ?think|已深度思考|深度思考|思考中)/i.test(head);
  };

  // The answer is the last markdown block plus its direct siblings inside the
  // same message bubble ("different messages have different parents").
  let answerRoots = [last];
  const parent = last.parentElement;
  if (parent) {
    const sibs = Array.from(parent.children).filter(
      (c) => c.nodeType === 1 && c.classList && c.classList.contains('ds-markdown')
    );
    if (sibs.length > 0 && sibs.length <= 12) answerRoots = sibs;
  }
  const content = answerRoots
    .map(textOf)
    .filter(Boolean)
    .join('\n\n');

  // The thinking panel renders as a *preceding sibling* subtree of the answer.
  let reasonRoot = null;
  let node = last;
  for (let up = 0; up < 6 && node && !reasonRoot; up++) {
    let sib = node.previousElementSibling;
    let guard = 0;
    while (sib && guard++ < 12) {
      if (sib.contains && sib.contains(last)) { sib = sib.previousElementSibling; continue; }
      if (looksReasoning(sib) && sib.querySelectorAll('.ds-markdown').length > 0) {
        reasonRoot = sib;
        break;
      }
      const inner = sib.querySelector(
        '[class*="think"],[class*="reason"],[data-testid*="think"],[data-testid*="reason"]'
      );
      if (inner && inner.querySelectorAll('.ds-markdown').length > 0) {
        reasonRoot = inner;
        break;
      }
      sib = sib.previousElementSibling;
    }
    node = node.parentElement;
  }

  let reasoning = '';
  if (reasonRoot) {
    reasoning = Array.from(reasonRoot.querySelectorAll('.ds-markdown'))
      .map(textOf)
      .filter(Boolean)
      .join('\n');
    // Drop the "Thought for 12 seconds" style header inside the panel.
    reasoning = reasoning
      .replace(/^(thought for[^\n]{0,48}|thinking[^\n]{0,48}|deep ?think[^\n]{0,48}|已深度思考[^\n]{0,48}|深度思考[^\n]{0,48})\n?/i, '')
      .trim();
  }
  return { reasoning: reasoning, content: content };
}
"""

# DeepSeek tags the *answer* with `ds-assistant-message-main-content` and the
# DeepThink panel with `ds-think-content`; both verified against the live app.
# Those two hooks make the split exact, including while thinking is still
# streaming and no answer block exists yet.
_EXTRACT_SEMANTIC_JS = r"""
() => {
""" + _JS_TEXT_HELPER + r"""
  const ANSWER = 'ds-assistant-message-main-content';
  const THINK = 'ds-think-content';
  const answerEls = Array.from(document.querySelectorAll('.' + ANSWER));
  const thinkEls = Array.from(document.querySelectorAll('.' + THINK));
  if (answerEls.length === 0 && thinkEls.length === 0) return null;

  const FOLLOWS = 4; // Node.DOCUMENT_POSITION_FOLLOWING
  const blockText = (root) => {
    const mds = root.querySelectorAll('.ds-markdown');
    return (mds.length ? Array.from(mds).map(textOf) : [textOf(root)])
      .filter(Boolean)
      .join('\n\n');
  };

  const answerEl = answerEls.length ? answerEls[answerEls.length - 1] : null;
  const content = answerEl ? blockText(answerEl) : '';

  // The thinking panel for THIS turn is the last think block that sits after
  // the previous answer and before the current one. While the answer is still
  // streaming there is no answer block, so the live panel is used directly.
  let chosen = null;
  if (thinkEls.length) {
    if (!answerEl) {
      chosen = thinkEls[thinkEls.length - 1];
    } else {
      const prevAnswer = answerEls.length > 1 ? answerEls[answerEls.length - 2] : null;
      for (let i = thinkEls.length - 1; i >= 0; i--) {
        const t = thinkEls[i];
        if (prevAnswer && !(prevAnswer.compareDocumentPosition(t) & FOLLOWS)) continue;
        if (!(t.compareDocumentPosition(answerEl) & FOLLOWS)) continue;
        chosen = t;
        break;
      }
    }
  }
  const reasoning = chosen
    ? blockText(chosen)
        .replace(/^(thought for[^\n]{0,48}|thinking[^\n]{0,48}|deep ?think[^\n]{0,48}|已深度思考[^\n]{0,48}|深度思考[^\n]{0,48})\n?/i, '')
        .trim()
    : '';

  return { reasoning: reasoning, content: content };
}
"""

_GENERATING_JS = r"""
() => {
  const blob = (el) => (
    ((el.getAttribute && (el.getAttribute('aria-label') || '')) || '') + ' ' +
    ((el.getAttribute && (el.getAttribute('title') || '')) || '') + ' ' +
    ((el.getAttribute && (el.getAttribute('data-testid') || '')) || '') + ' ' +
    (el.innerText || '')
  ).toLowerCase();
  for (const el of document.querySelectorAll('button, div[role="button"], [role="button"]')) {
    const s = blob(el);
    if (s.includes('stop') || s.includes('cancel') || s.includes('停止') || s.includes('中断')) {
      return true;
    }
  }
  return !!document.querySelector(
    '[class*="loading"],[class*="pulsing"],[class*="streaming"]'
  );
}
"""

_COUNT_JS = r"""
() => {
  const all = document.querySelectorAll('.ds-markdown');
  if (!all.length) return 0;
  let groups = 0;
  let lastParent = null;
  all.forEach((el) => {
    if (el.parentElement !== lastParent) { groups += 1; lastParent = el.parentElement; }
  });
  return groups;
}
"""

_SESSION_STORE_JS = (
    "(t) => localStorage.setItem('userToken', JSON.stringify({value: t, __version:'0'}))"
)


def _load_netscape_cookies(path: Path) -> List[Dict[str, Any]]:
    """Parse a Netscape cookies.txt file into Playwright ``add_cookies`` dicts.

    Tolerant by design: blank lines, comments and malformed rows are skipped,
    ``#HttpOnly_`` prefixes are honoured, ``expires == 0`` becomes a session
    cookie and already-expired rows are dropped instead of being rejected.
    """
    cookies: List[Dict[str, Any]] = []
    now = int(time.time())
    try:
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return cookies
    for line in lines:
        line = line.strip()
        http_only = line.startswith("#HttpOnly_")
        if http_only:
            line = line[len("#HttpOnly_"):]
        elif not line or line.startswith("#"):
            continue
        parts = line.split("\t")
        if len(parts) != 7:
            parts = line.split()
            if len(parts) != 7:
                continue
        domain, _include_sub, cpath, secure, expires, name, value = parts
        try:
            exp = int(float(expires))
        except ValueError:
            exp = 0
        cookie: Dict[str, Any] = {
            "name": name,
            "value": value,
            "domain": domain,
            "path": cpath or "/",
            "secure": secure.upper() == "TRUE",
            "httpOnly": http_only,
        }
        if exp > now:
            cookie["expires"] = exp
        cookies.append(cookie)
    return cookies


class Worker:
    """One persistent Chromium profile driving one DeepSeek chat tab."""

    def __init__(self, wid: int, profile: Path, pw: Any) -> None:
        self.wid = wid
        self.profile = profile
        self.pw = pw
        self.ctx: Any = None
        self.page: Any = None
        self.lock = asyncio.Lock()
        self.session_id: Optional[str] = None
        self.last_used: float = time.time()
        self.ready = False
        self.error: Optional[str] = None
        self.last_prompt: Optional[str] = None
        self._fresh = False  # False -> first turn resets the DeepSeek chat
        self._deep_think: Optional[bool] = None
        self._search: Optional[bool] = None

    # -- lifecycle ---------------------------------------------------------
    async def _launch(self) -> Any:
        return await self.pw.chromium.launch_persistent_context(
            str(self.profile),
            headless=False,
            args=[
                *(["--headless=new"] if HEADLESS else []),
                "--no-sandbox",
                "--disable-dev-shm-usage",
                "--disable-blink-features=AutomationControlled",
                "--window-size=1920,1080",
                f"--remote-debugging-port={9300 + self.wid}",
                "--disable-gpu",
            ],
            viewport={"width": 1920, "height": 1080},
            user_agent=HAR_UA,
            locale="en-US",
            timezone_id="America/New_York",
            ignore_default_args=["--enable-automation"],
        )

    def _profile_in_use(self) -> bool:
        """True when a live Chromium already owns this persistent profile."""
        marker = f"--user-data-dir={self.profile}"
        try:
            for entry in Path("/proc").iterdir():
                if not entry.name.isdigit():
                    continue
                with contextlib.suppress(OSError):
                    cmdline = (entry / "cmdline").read_bytes().replace(b"\x00", b" ")
                    if marker in cmdline.decode("utf-8", "replace"):
                        return True
        except Exception:
            return False
        return False

    def _clear_profile_locks(self) -> None:
        """Drop the Chromium ProcessSingleton files left by a killed run."""
        for name in ("SingletonLock", "SingletonSocket", "SingletonCookie"):
            path = self.profile / name
            with contextlib.suppress(OSError):
                if path.is_symlink() or path.exists():
                    path.unlink()

    async def _seed_cookies(self, cookies: List[Dict[str, Any]]) -> None:
        """Pre-load cookies (e.g. the AWS WAF token) before the first goto.

        A batch add is tried first; if any single row is rejected (bad domain
        shape, expired, ...) the rows are retried one by one so one bad line
        cannot take down the WAF token that actually matters.
        """
        try:
            await self.ctx.add_cookies(cookies)
            print(
                f"[w{self.wid}] seeded {len(cookies)} cookie(s) from {COOKIE_PATH.name}",
                flush=True,
            )
        except Exception:
            added = 0
            for cookie in cookies:
                try:
                    await self.ctx.add_cookies([cookie])
                    added += 1
                except Exception:
                    pass
            print(
                f"[w{self.wid}] seeded {added}/{len(cookies)} cookie(s) "
                "(some rows were rejected)",
                flush=True,
            )

    async def start(self) -> None:
        self.profile.mkdir(parents=True, exist_ok=True)
        try:
            self.ctx = await self._launch()
        except Exception as exc:  # noqa: BLE001 - retried once below
            blob = str(exc)
            if "Singleton" not in blob or self._profile_in_use():
                raise
            # A previously SIGKILLed Chromium left its lock behind; Chromium
            # then refuses to start forever until it is removed.
            print(f"[w{self.wid}] clearing stale profile lock and retrying", flush=True)
            self._clear_profile_locks()
            self.ctx = await self._launch()
        await self.ctx.add_init_script(
            "Object.defineProperty(navigator,'webdriver',{get:()=>undefined});"
            "window.chrome={runtime:{}};"
        )
        self.page = self.ctx.pages[0] if self.ctx.pages else await self.ctx.new_page()
        if _STEALTH is not None:
            with contextlib.suppress(Exception):
                await _STEALTH.apply_stealth_async(self.page)

        if COOKIE_PATH.exists():
            seed = _load_netscape_cookies(COOKIE_PATH)
            if seed:
                await self._seed_cookies(seed)

        await self.page.goto(
            DEEPSEEK_URL, wait_until="domcontentloaded", timeout=45_000
        )

        # Login BEFORE waiting for the shell: a fresh profile never shows the
        # composer textarea, so the stored token must land in localStorage and
        # the app reload before the wait below can ever succeed. The reload is
        # skipped when the profile already holds the same token.
        if TOKEN_PATH.exists():
            token = TOKEN_PATH.read_text(encoding="utf-8").strip()
            if token:
                stored = ""
                with contextlib.suppress(Exception):
                    stored = await self.page.evaluate(
                        "() => { try { return (JSON.parse(localStorage.getItem('userToken') || '{}').value) || ''; } catch { return ''; } }"
                    )
                if stored != token:
                    with contextlib.suppress(Exception):
                        await self.page.evaluate(_SESSION_STORE_JS, token)
                        await self.page.reload(wait_until="domcontentloaded")
                        await self.page.wait_for_timeout(2500)
        else:
            print(
                f"[w{self.wid}] WARNING: {TOKEN_PATH.name} missing - relying on "
                "the persistent profile/cookies; boot may end in a WAF loop",
                flush=True,
            )

        await self._wait_for_shell()

        self.ready = True
        self.error = None
        print(f"[w{self.wid}] ready", flush=True)

    async def _wait_for_shell(self) -> None:
        deadline = time.time() + BOOT_TIMEOUT
        while time.time() < deadline:
            with contextlib.suppress(Exception):
                has_box = await self.page.query_selector(SEL_TEXTAREA) is not None
                if has_box:
                    html = await self.page.content()
                    if "awsWaf" not in html:
                        return
            await asyncio.sleep(1)
        raise WorkerError(
            "DeepSeek UI did not become ready (textarea missing, WAF challenge, "
            "or token rejected)",
            code="boot_timeout",
        )

    async def stop(self) -> None:
        with contextlib.suppress(Exception):
            if self.ctx:
                await self.ctx.close()

    async def revive(self) -> None:
        """Tear down and rebuild the browser context for this worker."""
        await self.stop()
        self.ready = False
        self.last_prompt = None
        self._fresh = False
        self._deep_think = None
        self._search = None
        self.ctx = None
        self.page = None
        try:
            await self.start()
        except Exception as exc:  # noqa: BLE001 - surfaced to the client
            self.error = f"{type(exc).__name__}: {exc}"
            self.ready = False
            raise WorkerError(
                f"worker {self.wid} could not be restarted: {self.error}",
                code="worker_unavailable",
            ) from exc

    async def ensure_alive(self) -> None:
        if not self.ready or self.page is None:
            raise WorkerError(
                self.error or f"worker {self.wid} is not ready",
                code="worker_unavailable",
            )
        closed = False
        with contextlib.suppress(Exception):
            closed = self.page.is_closed()
        if closed:
            await self.revive()

    # -- page operations ---------------------------------------------------
    async def _new_chat_control(self) -> Any:
        """Return the innermost element labelled "New chat", if any.

        Ancestors also "contain" the text, and clicking one of those can land on
        empty space, so the shortest match is taken (i.e. the real control).
        """
        with contextlib.suppress(Exception):
            nodes = await self.page.query_selector_all(SEL_NEW_CHAT)
            best: Any = None
            best_len: Optional[int] = None
            for node in nodes:
                text = ((await node.inner_text()) or "").strip()
                if "new chat" not in text.lower():
                    continue
                if best_len is None or len(text) <= best_len:
                    best, best_len = node, len(text)
            return best
        return None

    async def new_chat(self, timeout_s: float = RESET_TIMEOUT) -> bool:
        """Clear the DeepSeek conversation, verifying that it actually cleared.

        Clicking "New chat" is best-effort in a single-page app and Playwright
        happily reports a click that changed nothing. A tab that still shows an
        earlier conversation would make the next answer look like it contains
        that conversation, so the reset is only considered successful once the
        message count has fallen to zero.
        """
        self.last_prompt = None
        self._fresh = False
        if await self.count() == 0:
            self._fresh = True
            return True
        for attempt in range(3):
            node = await self._new_chat_control()
            if node is not None:
                with contextlib.suppress(Exception):
                    await node.click()
            if attempt == 1:
                # Last resort: reload the app shell, which always starts on an
                # empty composer even if the sidebar still lists old chats.
                with contextlib.suppress(Exception):
                    await self.page.goto(
                        DEEPSEEK_URL, wait_until="domcontentloaded", timeout=30_000
                    )
                    await self.page.wait_for_timeout(1500)
            deadline = time.time() + timeout_s / 3
            while time.time() < deadline:
                await self.page.wait_for_timeout(400)
                if await self.count() == 0:
                    self._fresh = True
                    return True
        return False

    async def reset(self) -> None:
        """Clear the context, or fail loudly rather than answer on a stale tab."""
        if not await self.new_chat():
            raise WorkerError(
                "could not clear the DeepSeek conversation; refusing to answer "
                "on top of the previous one",
                code="reset_failed",
            )

    async def count(self) -> int:
        with contextlib.suppress(Exception):
            return int(await self.page.evaluate(_COUNT_JS))
        return 0

    async def snapshot(self) -> Dict[str, str]:
        """Scrape the last assistant message as ``{reasoning, content}``.

        The semantic selector is tried first; the structural fallback keeps
        working if DeepSeek renames the answer class.
        """
        for script in (_EXTRACT_SEMANTIC_JS, _EXTRACT_JS):
            with contextlib.suppress(Exception):
                data = await self.page.evaluate(script)
                if isinstance(data, dict):
                    return {
                        "reasoning": str(data.get("reasoning") or ""),
                        "content": str(data.get("content") or ""),
                    }
        return {"reasoning": "", "content": ""}

    async def _set_toggle(self, selector: str, enabled: bool) -> bool:
        """Flip a composer toggle and report the resulting state.

        Never raises: a missing toggle just means the capability is unavailable
        for this account/DOM revision.
        """
        try:
            toggle = await self.page.query_selector(selector)
            if toggle is None:
                return False
            pressed = (await toggle.get_attribute("aria-pressed")) == "true"
            if pressed != enabled:
                await toggle.click()
                await self.page.wait_for_timeout(400)
                toggle = await self.page.query_selector(selector)
                pressed = bool(toggle) and (
                    await toggle.get_attribute("aria-pressed")
                ) == "true"
            return pressed
        except Exception:
            return False

    async def set_deep_think(self, enabled: bool) -> bool:
        """Arm the DeepThink (R1) switch so the reply carries reasoning."""
        if self._deep_think is None or self._deep_think != enabled:
            self._deep_think = await self._set_toggle(SEL_DEEP_THINK, enabled)
        return bool(self._deep_think)

    async def set_web_search(self, enabled: bool) -> bool:
        """Arm the Search switch so DeepSeek browses before answering."""
        if self._search is None or self._search != enabled:
            self._search = await self._set_toggle(SEL_SEARCH, enabled)
        return bool(self._search)

    async def is_generating(self) -> bool:
        with contextlib.suppress(Exception):
            return bool(await self.page.evaluate(_GENERATING_JS))
        return False

    async def has_composer(self) -> bool:
        with contextlib.suppress(Exception):
            return await self.page.query_selector(SEL_TEXTAREA) is not None
        return False

    async def submit(self, prompt: str) -> None:
        try:
            await self.page.wait_for_selector(SEL_TEXTAREA, timeout=15_000)
            await self.page.fill(SEL_TEXTAREA, prompt)
            await self.page.wait_for_timeout(250)
            await self.page.keyboard.press("Enter")
        except Exception as exc:  # noqa: BLE001
            raise WorkerError(
                f"could not submit prompt: {type(exc).__name__}: {exc}",
                code="submit_failed",
            ) from exc

    async def begin(self, prompt: str) -> Tuple[str, int, Dict[str, str]]:
        """Prepare a turn: return ``(text_to_type, bubble_count, baseline)``.

        OpenCode resends the whole conversation on every request. Pinning the
        session means the tab already holds that history, so only the *new*
        suffix is typed. If the incoming conversation is not an extension of
        what the tab last saw, the chat is reset and the full prompt is sent.
        """
        await self.ensure_alive()
        prev = self.last_prompt
        if prev and prompt.startswith(prev) and len(prompt) > len(prev):
            delta = prompt[len(prev):].lstrip()
            if delta:
                self.last_prompt = prompt
                return delta, await self.count(), await self.snapshot()
        if prev is not None or not self._fresh:
            await self.reset()
        self._fresh = False
        self.last_prompt = prompt
        before = await self.count()
        baseline = await self.snapshot()
        if before or baseline["content"] or baseline["reasoning"]:
            # The tab claims to be fresh but is not; clear it again instead of
            # building the answer on top of another conversation.
            if not await self.new_chat():
                raise WorkerError(
                    "could not clear the DeepSeek conversation; refusing to answer "
                    "on top of the previous one",
                    code="reset_failed",
                )
            before = await self.count()
            baseline = await self.snapshot()
        return prompt, before, baseline

    async def stream(
        self,
        before_count: int = 0,
        baseline: Optional[Dict[str, str]] = None,
        tick: float = POLL_TICK,
        stable_ticks: int = STABLE_TICKS,
        timeout_s: float = STREAM_TIMEOUT,
        first_token_s: float = FIRST_TOKEN_TIMEOUT,
        busy_grace: float = BUSY_GRACE,
    ) -> AsyncIterator[Dict[str, str]]:
        """Yield ``{reasoning, content}`` snapshots until the answer settles.

        ``baseline`` is the page state sampled *before* the prompt was sent, and
        ``before_count`` the number of message bubbles at that time (kept for
        diagnostics and tests). A snapshot identical to the baseline is never
        emitted, so a previous conversation still on screen can never be
        reported as this answer.

        The text stopping is the primary completion signal. The UI's generating
        state only *extends* the wait, and only for ``busy_grace`` seconds, so a
        persistently busy indicator can never stall a turn forever.
        """
        baseline = baseline or {"reasoning": "", "content": ""}
        start = time.time()
        deadline = start + timeout_s
        last: Optional[Dict[str, str]] = None
        unchanged = 0
        stable_since = start
        while time.time() < deadline:
            await asyncio.sleep(tick)
            snap = await self.snapshot()
            if snap == baseline:
                # Nothing new yet. Returning ``before_count`` bubbles of old
                # text here is exactly the bug this guard exists for.
                if time.time() - start > first_token_s:
                    return
                continue
            if snap != last:
                last = snap
                unchanged = 0
                stable_since = time.time()
                yield snap
                continue
            unchanged += 1
            if not (snap.get("content") or snap.get("reasoning")):
                if time.time() - start > first_token_s:
                    return
                continue
            if unchanged < stable_ticks:
                continue
            if await self.is_generating() and time.time() - stable_since < busy_grace:
                continue
            return


class Pool:
    """Fixed-size worker pool with per-session pinning and safe eviction."""

    def __init__(self, size: int) -> None:
        self.size = size
        self.workers: List[Worker] = []
        self.free: asyncio.Queue[Worker] = asyncio.Queue()
        self.sessions: Dict[str, Worker] = {}
        self.pw: Any = None
        self._lock = asyncio.Lock()
        self._boot_tasks: List[asyncio.Task[None]] = []

    async def start(self) -> None:
        """Start Playwright and boot workers in the background."""
        self.pw = await async_playwright().start()
        for i in range(self.size):
            worker = Worker(i, WORKERS_DIR / f"worker_{i}", self.pw)
            self.workers.append(worker)
            self._boot_tasks.append(asyncio.create_task(self._boot(worker)))

    async def _boot(self, worker: Worker, attempts: int = 8) -> None:
        """Boot a worker, retrying with backoff.

        A previous run's Chromium can still hold the profile for a while after
        the wrapper is killed, and Playwright refuses to open a locked profile.
        Rather than leaving the pool permanently down, keep retrying so the
        worker comes up on its own once the old browser exits.
        """
        for attempt in range(1, attempts + 1):
            try:
                await worker.start()
            except Exception as exc:  # noqa: BLE001 - surfaced through /health
                worker.error = f"{type(exc).__name__}: {exc}"
                worker.ready = False
                print(
                    f"[w{worker.wid}] boot attempt {attempt}/{attempts} failed: "
                    f"{str(exc).splitlines()[0][:140]}",
                    flush=True,
                )
                if attempt == attempts:
                    return
                await worker.stop()  # drop any half-opened context
                await asyncio.sleep(min(30, 2 ** attempt))
                continue
            worker.error = None
            self.free.put_nowait(worker)
            return

    async def stop(self) -> None:
        for task in self._boot_tasks:
            task.cancel()
        for task in self._boot_tasks:
            with contextlib.suppress(asyncio.CancelledError, Exception):
                await task
        for worker in self.workers:
            await worker.stop()
        with contextlib.suppress(Exception):
            if self.pw:
                await self.pw.stop()

    def worker(self, wid: int) -> Optional[Worker]:
        for w in self.workers:
            if w.wid == wid:
                return w
        return None

    @asynccontextmanager
    async def lease(self, session_id: str) -> AsyncIterator[Worker]:
        """Pin ``session_id`` to a worker for the duration of the request.

        Eviction only ever takes an *unlocked* worker, so a session can never
        lose the tab that another in-flight request is streaming from.
        """
        deadline = time.time() + LEASE_TIMEOUT
        worker: Optional[Worker] = None
        reset_needed = False

        while worker is None:
            async with self._lock:
                existing = self.sessions.get(session_id)
                if existing is not None and existing.ready:
                    worker = existing
                    break
                if existing is not None:  # worker died; unpin it
                    self.sessions.pop(session_id, None)
                    existing.session_id = None

                try:
                    worker = self.free.get_nowait()
                except asyncio.QueueEmpty:
                    worker = None
                if worker is not None:
                    self.sessions[session_id] = worker
                    worker.session_id = session_id
                    break

                victim_sid = None
                for sid, cand in sorted(
                    self.sessions.items(), key=lambda kv: kv[1].last_used
                ):
                    if cand.ready and not cand.lock.locked():
                        victim_sid = sid
                        break
                if victim_sid is not None:
                    victim = self.sessions.pop(victim_sid)
                    victim.session_id = session_id
                    self.sessions[session_id] = victim
                    worker = victim
                    reset_needed = True
                    break

                booting = any(w.ready or w.error is None for w in self.workers)

            if not booting and not self.free.qsize():
                raise WorkerError(
                    "no browser worker is available",
                    code="pool_unavailable",
                )
            if time.time() > deadline:
                raise WorkerError(
                    "timed out waiting for a free browser worker",
                    code="pool_timeout",
                )
            await asyncio.sleep(0.4)

        await worker.lock.acquire()
        try:
            if reset_needed:
                await worker.reset()
            worker.last_used = time.time()
            yield worker
        finally:
            worker.last_used = time.time()
            worker.lock.release()

    async def drop(self, session_id: str) -> bool:
        async with self._lock:
            worker = self.sessions.pop(session_id, None)
        if worker is None:
            return False
        worker.session_id = None
        async with worker.lock:
            with contextlib.suppress(Exception):
                await worker.reset()
        self.free.put_nowait(worker)
        return True

    def stats(self) -> Dict[str, Any]:
        return {
            "ready": bool(self.workers) and all(w.ready for w in self.workers),
            "free": self.free.qsize(),
            "sessions": list(self.sessions.keys()),
            "workers": [
                WorkerStatus(
                    id=w.wid,
                    ready=w.ready,
                    busy=w.lock.locked(),
                    session_id=w.session_id,
                    last_used=w.last_used,
                    error=w.error,
                )
                for w in self.workers
            ],
        }


# --------------------------------------------------------------------------- #
# response helpers
# --------------------------------------------------------------------------- #
STREAM_HEADERS = {
    "Cache-Control": "no-cache, no-transform",
    "Connection": "keep-alive",
    "X-Accel-Buffering": "no",
}


def _sse(payload: Dict[str, Any]) -> str:
    """Serialise one schema-valid ``chat.completion.chunk`` SSE frame."""
    return "data: " + json.dumps(payload, ensure_ascii=False) + "\n\n"


DONE_FRAME = "data: [DONE]\n\n"


def _chunk(
    cid: str,
    model: str,
    created: int,
    delta: Optional[Dict[str, Any]] = None,
    finish: Optional[str] = None,
) -> str:
    """A chunk frame always carrying ``choices`` (required by the AI SDK schema)."""
    return _sse(
        {
            "id": cid,
            "object": "chat.completion.chunk",
            "created": created,
            "model": model,
            "system_fingerprint": "deepseek-web",
            "choices": [
                {
                    "index": 0,
                    "delta": delta or {},
                    "finish_reason": finish,
                }
            ],
        }
    )


def _usage_frame(cid: str, model: str, created: int, usage: Dict[str, Any]) -> str:
    """A usage-only frame. ``choices`` must still be present, so it is empty."""
    return _sse(
        {
            "id": cid,
            "object": "chat.completion.chunk",
            "created": created,
            "model": model,
            "system_fingerprint": "deepseek-web",
            "choices": [],
            "usage": usage,
        }
    )


def _estimate_tokens(text: str) -> int:
    if not text:
        return 0
    return max(1, len(text) // 4)


def _build_usage(
    prompt_text: str,
    content_text: str,
    reasoning_text: str = "",
    tool_calls: Optional[List[Dict[str, Any]]] = None,
) -> Dict[str, Any]:
    prompt_tokens = _estimate_tokens(prompt_text)
    reasoning_tokens = _estimate_tokens(reasoning_text)
    call_text = "".join(
        tc.get("function", {}).get("arguments", "") for tc in (tool_calls or [])
    )
    completion_tokens = _estimate_tokens(content_text + call_text) + reasoning_tokens
    return {
        "prompt_tokens": prompt_tokens,
        "completion_tokens": completion_tokens,
        "total_tokens": prompt_tokens + completion_tokens,
        "prompt_tokens_details": {"cached_tokens": 0},
        "completion_tokens_details": {
            "reasoning_tokens": reasoning_tokens,
            "accepted_prediction_tokens": 0,
            "rejected_prediction_tokens": 0,
        },
    }


def _finish_reason(
    tool_calls: Optional[List[Dict[str, Any]]],
    content: str,
    max_tokens: Optional[int],
) -> str:
    if tool_calls:
        return "tool_calls"
    if max_tokens and _estimate_tokens(content) >= max_tokens:
        return "length"
    return "stop"


class _ToolSniffer:
    """Turns successive full-text snapshots into an incremental text stream.

    Also holds back text that looks like the start of a tool-call payload:
    without that, the raw ``{"tool_calls": ...}`` JSON the model was asked to
    emit would reach the client as visible prose before it could be converted
    into structured ``tool_calls``. Anything withheld is released as content if
    no call is found by the end of the turn.
    """

    # "DSML" is the token inside the model's native tool-call markup; including
    # it means that format is withheld too, not just the JSON protocol.
    MARKERS = ('"tool_calls"', "```json", "```JSON", "<tool_call>", "DSML")
    # Always withhold the trailing window so a marker split across two polls (or
    # a partially rendered code block) cannot leak as prose.
    HOLD_BACK = 24

    def __init__(self, enabled: bool) -> None:
        self.enabled = enabled
        self._prev = ""
        self._sent = 0  # chars of the emittable prefix already streamed

    def feed(self, full_text: str) -> str:
        """Return the newly emittable text for a fresh full-text snapshot."""
        if self._prev and not full_text.startswith(self._prev):
            # The DOM rewrote earlier text; resync instead of duplicating.
            lcp = 0
            limit = min(len(self._prev), len(full_text))
            while lcp < limit and self._prev[lcp] == full_text[lcp]:
                lcp += 1
            self._sent = min(self._sent, lcp)
        self._prev = full_text

        cut = len(full_text)
        if self.enabled:
            found = False
            for marker in self.MARKERS:
                pos = full_text.find(marker)
                if pos == -1:
                    continue
                found = True
                # Walk back over the payload's opening punctuation so the brace
                # or tag opener is withheld too, never just the marker itself.
                i = pos
                while i > 0:
                    char = full_text[i - 1]
                    if char in " \t\n`<>{}|\uff5c":
                        i -= 1
                        continue
                    if full_text[max(0, i - len(_DSML_TOKEN)) : i] == _DSML_TOKEN:
                        i -= len(_DSML_TOKEN)
                        continue
                    break
                cut = min(cut, i)
            if not found:
                # No payload in sight: hold back a window so a marker split
                # across two polls can never leak as prose.
                cut = max(0, len(full_text) - self.HOLD_BACK)

        if cut <= self._sent:
            return ""
        new = full_text[self._sent:cut]
        self._sent = cut
        return new

    def flush(self) -> str:
        """Release everything withheld, once we know it is not a tool call."""
        tail = self._prev[self._sent:]
        self._sent = len(self._prev)
        return tail


def _resolve_session_id(req: ChatRequest, request: Request) -> str:
    explicit = (
        req.session_id
        or request.headers.get("x-session-id")
        or req.user
        or (isinstance(req.model_extra, dict) and req.model_extra.get("session_id"))
    )
    if explicit:
        return str(explicit)[:128]
    raw = json.dumps(
        [
            {"role": m.role, "content": _text_of(m.content)}
            for m in req.messages[:2]
        ],
        sort_keys=True,
        ensure_ascii=False,
    )
    return "sess-" + hashlib.sha256(raw.encode("utf-8")).hexdigest()[:12]


def _canon_model(model: Optional[str]) -> str:
    """Map any accepted model id (or alias) to the canonical "deepseek"."""
    name = (model or "deepseek").strip()
    return MODEL_ALIASES.get(name.lower(), name.lower())


async def _start_turn(
    worker: Worker, req: ChatRequest, prompt: str
) -> Tuple[str, int, Dict[str, str]]:
    """Clear context if asked, arm the composer toggles, snapshot the baseline."""
    if req.reset:
        await worker.reset()
    turn, before, baseline = await worker.begin(prompt)
    # Thinking is always on: every reply carries DeepThink reasoning.
    await worker.set_deep_think(True)
    await worker.set_web_search(bool(req.web_search))
    return turn, before, baseline


def _error_response(status: int, message: str, *, type_: str, code: str) -> JSONResponse:
    return JSONResponse(
        status_code=status,
        content={
            "error": {"message": message, "type": type_, "param": None, "code": code}
        },
    )


# --------------------------------------------------------------------------- #
# application
# --------------------------------------------------------------------------- #
pool: Optional[Pool] = None


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    """Replaces the deprecated ``@app.on_event`` hooks."""
    global pool
    pool = Pool(POOL_SIZE)
    await pool.start()
    try:
        yield
    finally:
        await pool.stop()
        pool = None


app = FastAPI(
    title="DeepSeek Wrapper",
    version=VERSION,
    description=(
        "An OpenAI-compatible gateway to DeepSeek's web chat, driven by a "
        "Playwright worker pool. Built to be used directly by OpenCode as a "
        "`@ai-sdk/openai-compatible` provider."
    ),
    lifespan=lifespan,
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Meta routes stay open for monitoring; OPTIONS is exempt so browser CORS
# preflights are never killed by the key check.
_OPEN_PATHS = frozenset({"/", "/health", "/docs", "/openapi.json", "/redoc"})


@app.middleware("http")
async def _api_key_guard(request: Request, call_next: Any) -> Any:
    """Optional shared-secret gate (``DS_API_KEY``).

    OpenCode's ``openai-compatible`` provider sends the configured ``apiKey``
    as ``Authorization: Bearer <key>``, so the same value works on both sides.
    When the variable is unset, every endpoint stays open (loopback use).
    """
    if (
        API_KEY
        and request.method != "OPTIONS"
        and request.url.path not in _OPEN_PATHS
    ):
        supplied = ""
        auth = request.headers.get("authorization", "")
        if auth[:7].lower() == "bearer ":
            supplied = auth[7:].strip()
        supplied = supplied or request.headers.get("x-api-key", "").strip()
        if not supplied or not hmac.compare_digest(
            supplied.encode("utf-8"), API_KEY.encode("utf-8")
        ):
            return _error_response(
                401,
                "invalid or missing API key (server has DS_API_KEY set)",
                type_="invalid_request_error",
                code="invalid_api_key",
            )
    return await call_next(request)


@app.exception_handler(HTTPException)
async def _http_exception_handler(request: Request, exc: HTTPException) -> JSONResponse:
    return _error_response(
        exc.status_code,
        str(exc.detail),
        type_="invalid_request_error" if exc.status_code < 500 else "server_error",
        code=f"http_{exc.status_code}",
    )


@app.exception_handler(RequestValidationError)
async def _validation_exception_handler(
    request: Request, exc: RequestValidationError
) -> JSONResponse:
    return _error_response(
        400,
        json.dumps(exc.errors(), default=str),
        type_="invalid_request_error",
        code="validation_error",
    )


@app.exception_handler(Exception)
async def _unhandled_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    print(f"[error] {request.method} {request.url.path}: {type(exc).__name__}: {exc}",
          flush=True)
    return _error_response(
        500,
        f"{type(exc).__name__}: {exc}",
        type_="server_error",
        code="internal_error",
    )


def _require_pool() -> Pool:
    if pool is None:
        raise HTTPException(503, "browser pool is not started")
    return pool


@app.get(
    "/",
    response_model=RootResponse,
    summary="Service index",
    tags=["meta"],
)
async def root() -> RootResponse:
    """Lists every route. ``/docs`` has the interactive OpenAPI explorer."""
    routes = [
        RouteInfo(method="GET", path="/", summary="This index"),
        RouteInfo(method="GET", path="/docs", summary="Swagger UI"),
        RouteInfo(method="GET", path="/openapi.json", summary="OpenAPI 3.1 document"),
        RouteInfo(method="GET", path="/health", summary="Pool + worker readiness"),
        RouteInfo(method="GET", path="/v1/models", summary="OpenAI model list"),
        RouteInfo(
            method="POST",
            path="/v1/chat/completions",
            summary="Chat completions (JSON or SSE)",
        ),
        RouteInfo(method="DELETE", path="/sessions/{session_id}", summary="Unpin a session"),
        RouteInfo(
            method="POST", path="/sessions/{session_id}/reset", summary="Reset a session"
        ),
        RouteInfo(
            method="GET",
            path="/debug/dom/{session_id}",
            summary="Dump live page HTML (selector debugging)",
        ),
        RouteInfo(
            method="GET",
            path="/debug/extract/{session_id}",
            summary="Show the parsed reasoning/content split",
        ),
        RouteInfo(
            method="GET",
            path="/debug/selectors/{session_id}",
            summary="Report which tracked selectors currently match",
        ),
        RouteInfo(
            method="POST",
            path="/debug/reset/{session_id}",
            summary="Force a conversation reset and verify it",
        ),
    ]
    return RootResponse(
        name="DeepSeek Wrapper",
        version=VERSION,
        docs="/docs",
        openapi="/openapi.json",
        routes=routes,
    )


@app.get(
    "/health",
    response_model=HealthResponse,
    summary="Pool statistics and worker readiness",
    tags=["meta"],
)
async def health() -> HealthResponse:
    """Never 500s: a missing pool reports ``ready: false``."""
    if pool is None:
        return HealthResponse(
            ready=False,
            version=VERSION,
            pool_size=0,
            free=0,
            workers_ready=0,
            sessions=[],
            workers=[],
        )
    stats = pool.stats()
    return HealthResponse(
        ready=stats["ready"],
        version=VERSION,
        pool_size=pool.size,
        free=stats["free"],
        workers_ready=sum(1 for w in pool.workers if w.ready),
        sessions=stats["sessions"],
        workers=stats["workers"],
    )


@app.get(
    "/v1/models",
    response_model=ModelList,
    summary="List available models",
    tags=["openai"],
)
@app.get("/models", response_model=ModelList, include_in_schema=False)
async def models() -> ModelList:
    created = int(time.time())
    return ModelList(
        data=[
            ModelCard(id=mid, created=created, owned_by="deepseek") for mid in MODEL_IDS
        ]
    )


@app.delete(
    "/sessions/{session_id}",
    response_model=SessionDeleted,
    responses={404: {"model": ErrorResponse, "description": "No such session"}},
    summary="Unpin a session and return its worker to the pool",
    tags=["sessions"],
)
async def drop_session(session_id: str) -> SessionDeleted:
    current = _require_pool()
    if not await current.drop(session_id):
        raise HTTPException(404, f"no such session: {session_id}")
    return SessionDeleted(deleted=session_id)


@app.post(
    "/sessions/{session_id}/reset",
    response_model=SessionReset,
    summary="Clear the DeepSeek context for a pinned session",
    tags=["sessions"],
)
async def reset_session(session_id: str) -> SessionReset:
    current = _require_pool()
    if session_id not in current.sessions:
        raise HTTPException(404, f"no such session: {session_id}")
    async with current.lease(session_id) as worker:
        await worker.reset()
    return SessionReset(reset=session_id)


WATCHED_SELECTORS = (
    SEL_NEW_CHAT,
    SEL_TEXTAREA,
    SEL_DEEP_THINK,
    SEL_SEARCH,
    ".ds-markdown",
    ".ds-assistant-message-main-content",
    ".ds-think-content",
)


@app.get(
    "/debug/selectors/{session_id}",
    response_model=SelectorReport,
    summary="Report which tracked selectors currently match on the live page",
    tags=["debug"],
)
async def debug_selectors(session_id: str) -> SelectorReport:
    """The first stop when a selector stops working after a DeepSeek release."""
    current = _require_pool()
    worker = _worker_for_debug(current, session_id)
    matches: List[SelectorMatch] = []
    for selector in WATCHED_SELECTORS:
        count = 0
        snippet: Optional[str] = None
        with contextlib.suppress(Exception):
            nodes = await worker.page.query_selector_all(selector)
            count = len(nodes)
            if nodes:
                outer = await nodes[0].evaluate("el => el.outerHTML")
                snippet = str(outer)[:200]
        matches.append(SelectorMatch(selector=selector, count=count, snippet=snippet))
    return SelectorReport(
        session_id=session_id,
        message_count=await worker.count(),
        matches=matches,
    )


@app.post(
    "/debug/reset/{session_id}",
    response_model=SessionReset,
    responses={503: {"model": ErrorResponse, "description": "Reset failed"}},
    summary="Force a conversation reset and report whether it worked",
    tags=["debug"],
)
async def debug_reset(session_id: str) -> SessionReset:
    current = _require_pool()
    if session_id not in current.sessions:
        raise HTTPException(404, f"no such session: {session_id}")
    async with current.lease(session_id) as worker:
        if not await worker.new_chat():
            raise HTTPException(
                503,
                f"could not clear conversation for '{session_id}' "
                f"(message count still {await worker.count()})",
            )
    return SessionReset(reset=session_id)


def _worker_for_debug(current: Pool, session_id: str) -> Worker:
    """Resolve a session id, or the accepted shorthand ``worker-<n>``/``<n>``."""
    worker = current.sessions.get(session_id)
    if worker is not None:
        return worker
    match = re.fullmatch(r"(?:worker[-_])?(\d+)", session_id)
    if match:
        worker = current.worker(int(match.group(1)))
        if worker is not None:
            return worker
    raise HTTPException(
        404,
        f"no worker is bound to session '{session_id}'. "
        f"Known sessions: {list(current.sessions) or 'none'} "
        f"(or use worker-<0..{current.size - 1}>)",
    )


@app.get(
    "/debug/dom/{session_id}",
    response_class=PlainTextResponse,
    responses={
        200: {"content": {"text/plain": {"schema": {"type": "string"}}}},
        404: {"model": ErrorResponse, "description": "Unknown session"},
    },
    summary="Dump the live page HTML for selector debugging",
    tags=["debug"],
)
async def debug_dom(
    session_id: str,
    tail: int = Query(15000, ge=0, le=2_000_000, description="Keep only the last N chars"),
) -> PlainTextResponse:
    current = _require_pool()
    worker = _worker_for_debug(current, session_id)
    try:
        html = await worker.page.content()
    except Exception as exc:  # noqa: BLE001
        return PlainTextResponse(
            f"<!-- could not read page: {type(exc).__name__}: {exc} -->", status_code=200
        )
    return PlainTextResponse(html[-tail:] if tail else html)


@app.get(
    "/debug/extract/{session_id}",
    response_model=ExtractDebug,
    summary="Show the reasoning/content split scraped from the live page",
    tags=["debug"],
)
async def debug_extract(session_id: str) -> ExtractDebug:
    current = _require_pool()
    worker = _worker_for_debug(current, session_id)
    snap = await worker.snapshot()
    return ExtractDebug(
        session_id=session_id,
        reasoning=snap["reasoning"],
        content=snap["content"],
        textarea_present=await worker.has_composer(),
        generating=await worker.is_generating(),
        deep_think=worker._deep_think,
        web_search=worker._search,
    )


@app.post(
    "/v1/chat/completions",
    response_model=ChatCompletion,
    responses={
        200: {
            "description": (
                "A `ChatCompletion` when `stream` is false, otherwise an SSE "
                "stream of `chat.completion.chunk` frames terminated by "
                "`data: [DONE]`."
            ),
            "content": {
                "text/event-stream": {
                    "schema": {"$ref": "#/components/schemas/ChatCompletionChunk"},
                    "example": (
                        'data: {"id":"chatcmpl-1","object":"chat.completion.chunk",'
                        '"created":0,"model":"deepseek","choices":[{"index":0,'
                        '"delta":{"role":"assistant"},"finish_reason":null}]}\n\n'
                        "data: [DONE]\n\n"
                    ),
                }
            },
        },
        400: {"model": ErrorResponse, "description": "Malformed request"},
        503: {"model": ErrorResponse, "description": "Pool or worker unavailable"},
    },
    summary="Create a chat completion (streaming or not)",
    tags=["openai"],
)
@app.post("/chat/completions", response_model=ChatCompletion, include_in_schema=False)
async def chat_completions(req: ChatRequest, request: Request):
    """OpenAI Chat Completions.

    Every SSE line is a schema-valid ``chat.completion.chunk``; nothing else is
    ever written to the stream.
    """
    current = _require_pool()
    session_id = _resolve_session_id(req, request)
    prompt = _messages_to_prompt(req.messages, req.tools, req.tool_choice)
    cid = f"chatcmpl-{uuid.uuid4().hex[:24]}"
    created = int(time.time())
    model = _canon_model(req.model)
    max_tokens = req.max_tokens or req.max_completion_tokens

    if req.stream:
        return StreamingResponse(
            _stream_events(
                current, req, request, session_id, prompt, cid, created, model, max_tokens
            ),
            media_type="text/event-stream",
            headers=STREAM_HEADERS,
        )

    worker: Optional[Worker] = None
    try:
        async with current.lease(session_id) as worker:
            try:
                turn, before, baseline = await _start_turn(worker, req, prompt)
                await worker.submit(turn)
                final: Dict[str, str] = {"reasoning": "", "content": ""}
                async for snap in worker.stream(before, baseline):
                    final = snap
                if not final["content"] and not final["reasoning"]:
                    raise WorkerError(
                        "DeepSeek returned no output (selector miss or empty reply)",
                        code="empty_response",
                    )
            except HTTPException:
                worker.last_prompt = None
                raise
            except BaseException:
                # The tab's history no longer matches what we sent, so the next
                # request must resend the whole conversation on a fresh chat.
                worker.last_prompt = None
                raise
    except WorkerError as exc:
        raise HTTPException(exc.status, str(exc)) from exc
    except HTTPException:
        raise
    except Exception as exc:  # noqa: BLE001
        if worker is not None:
            worker.last_prompt = None
        raise HTTPException(
            503, f"browser worker failed: {type(exc).__name__}: {exc}"
        ) from exc

    content, tool_calls = _extract_tool_calls(final["content"], req.tools)
    message = AssistantMessage(
        role="assistant",
        content=content or None,
        reasoning_content=final["reasoning"] or None,
        tool_calls=(
            [ToolCall(**tc) for tc in tool_calls] if tool_calls else None
        ),
    )
    if message.tool_calls and not content:
        message.content = None

    return ChatCompletion(
        id=cid,
        created=created,
        model=model,
        choices=[
            ChatCompletionChoice(
                index=0,
                message=message,
                finish_reason=_finish_reason(tool_calls, content or "", max_tokens),
                logprobs=None,
            )
        ],
        usage=Usage(
            **_build_usage(prompt, content or "", final["reasoning"], tool_calls)
        ),
    )


async def _stream_events(
    current: Pool,
    req: ChatRequest,
    request: Request,
    session_id: str,
    prompt: str,
    cid: str,
    created: int,
    model: str,
    max_tokens: Optional[int],
) -> AsyncIterator[str]:
    """The SSE body. Always ends with a finish_reason frame plus ``[DONE]``."""
    final: Dict[str, str] = {"reasoning": "", "content": ""}
    tool_calls: Optional[List[Dict[str, Any]]] = None
    content = ""
    usage: Optional[Dict[str, Any]] = None
    finish = "stop"
    sniffer = _ToolSniffer(enabled=bool(req.tools))
    sent_reasoning = ""
    worker: Optional[Worker] = None
    turn_ok = False

    try:
        async with current.lease(session_id) as worker:
            try:
                turn, before, baseline = await _start_turn(worker, req, prompt)
                await worker.submit(turn)
            except BaseException:
                worker.last_prompt = None
                raise

            yield _chunk(
                cid, model, created, {"role": "assistant", "content": ""}
            )

            async for snap in worker.stream(before, baseline):
                if await request.is_disconnected():
                    return
                final = snap
                reasoning = snap["reasoning"]
                if reasoning.startswith(sent_reasoning):
                    delta = reasoning[len(sent_reasoning):]
                    sent_reasoning = reasoning
                    if delta:
                        yield _chunk(
                            cid, model, created, {"reasoning_content": delta}
                        )
                elif reasoning:
                    sent_reasoning = reasoning

                emittable = sniffer.feed(snap["content"])
                if emittable:
                    yield _chunk(cid, model, created, {"content": emittable})

            content, tool_calls = _extract_tool_calls(final["content"], req.tools)
            if tool_calls is None:
                # Nothing callable was found, so whatever we withheld is prose.
                flushed = sniffer.flush()
                if flushed:
                    yield _chunk(cid, model, created, {"content": flushed})
                content = final["content"]
            else:
                content = content or ""
                for index, tc in enumerate(tool_calls):
                    yield _chunk(
                        cid,
                        model,
                        created,
                        {
                            "tool_calls": [
                                {
                                    "index": index,
                                    "id": tc["id"],
                                    "type": "function",
                                    "function": {
                                        "name": tc["function"]["name"],
                                        "arguments": tc["function"]["arguments"],
                                    },
                                }
                            ]
                        },
                    )

            finish = _finish_reason(tool_calls, content, max_tokens)
            usage = _build_usage(prompt, content, final["reasoning"], tool_calls)
            turn_ok = True

    except WorkerError as exc:
        # Headers are already sent, so surface the failure as a schema-valid
        # terminal chunk rather than an invalid frame.
        print(f"[stream] {session_id}: {exc}", flush=True)
        finish = "stop"
        usage = _build_usage(prompt, content or "", final["reasoning"], tool_calls)
    except asyncio.CancelledError:
        raise
    except Exception as exc:  # noqa: BLE001
        print(f"[stream] {session_id}: unexpected {type(exc).__name__}: {exc}", flush=True)
        finish = "stop"
        usage = _build_usage(prompt, content or "", final["reasoning"], tool_calls)
    finally:
        if worker is not None and not turn_ok:
            # The tab's history no longer matches what we sent, so the next
            # request must resend the whole conversation on a fresh chat.
            worker.last_prompt = None

    yield _chunk(cid, model, created, {}, finish=finish)
    if usage is not None:
        yield _usage_frame(cid, model, created, usage)
    yield DONE_FRAME


if __name__ == "__main__":
    uvicorn.run(app, host=HOST, port=PORT, log_level="info")
