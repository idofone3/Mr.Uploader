#!/usr/bin/env bash
# Restart the wrapper cleanly.
#   usage: bash restart.sh [port] [pool_size]
# Lives in a file so the kill patterns cannot match the caller's own command
# line (a bare `pkill -f "python3 app.py"` at a shell prompt kills that shell).
set -u
cd "$(dirname "$0")" || exit 1

# Optional environment (DS_POOL_SIZE, DS_API_KEY, ...) lives in .env;
# app.py itself only reads os.environ, so exporting here is what makes it work.
if [ -f .env ]; then
  set -a
  . ./.env
  set +a
fi

# Interpreter: run.sh may export PY (venv python); else prefer .venv, else python3.
PYTHON="${DS_PYTHON:-${PY:-}}"
if [ -z "$PYTHON" ]; then
  if [ -x ".venv/bin/python" ]; then PYTHON="$(pwd)/.venv/bin/python"; else PYTHON="python3"; fi
fi

PORT="${1:-8000}"
POOL="${2:-2}"
LOG="api.log"
PIDFILE="api.pid"
PROFILE_MATCH="user-data-dir=$(pwd)/pool_workers"

# 1. Stop the wrapper holding the port (pidfile first, then port listener).
if [ -f "$PIDFILE" ]; then
  kill "$(cat "$PIDFILE")" 2>/dev/null || true
  rm -f "$PIDFILE"
fi
PIDS=""
if command -v ss >/dev/null 2>&1; then
  PIDS="$(ss -ltnp 2>/dev/null | grep ":${PORT} " | grep -oP 'pid=\K[0-9]+' | sort -u)"
fi
if [ -n "$PIDS" ]; then
  echo "stopping listener(s) on :${PORT}: ${PIDS}"
  # shellcheck disable=SC2086
  kill $PIDS 2>/dev/null
fi
pkill -f "python[0-9.]* app\.py" 2>/dev/null

# 2. Reap Chromium left over from a previous run. It keeps a ProcessSingleton
#    lock on the profile and is why the next boot would otherwise stall.
for _ in $(seq 1 30); do
  RPIDS="$(pgrep -f "$PROFILE_MATCH" 2>/dev/null | tr '\n' ' ')"
  [ -z "$RPIDS" ] && break
  # shellcheck disable=SC2086
  kill $RPIDS 2>/dev/null
  sleep 1
done
RPIDS="$(pgrep -f "$PROFILE_MATCH" 2>/dev/null | tr '\n' ' ')"
if [ -n "$RPIDS" ]; then
  echo "force-killing leftover browser(s): ${RPIDS}"
  # shellcheck disable=SC2086
  kill -9 $RPIDS 2>/dev/null
  sleep 2
fi
# Any lock whose owner is now gone is safe to drop.
for d in pool_workers/worker_*; do
  [ -d "$d" ] || continue
  rm -f "$d/SingletonLock" "$d/SingletonSocket" "$d/SingletonCookie"
done

# 3. Wait for the port to be released.
if command -v ss >/dev/null 2>&1; then
  for _ in $(seq 1 40); do
    [ -z "$(ss -ltn 2>/dev/null | grep ":${PORT} ")" ] && break
    sleep 0.5
  done
else
  sleep 2
fi

# 4. Start a fresh instance.
DS_POOL_SIZE="$POOL" DS_POOL_PORT="$PORT" setsid nohup "$PYTHON" app.py > "$LOG" 2>&1 < /dev/null &
echo $! > "$PIDFILE"

# 5. Wait for every worker to report ready (boots can take a while after a
#    forced restart, hence the generous budget).
for i in $(seq 1 100); do
  sleep 2
  BODY="$(curl -s -m 3 "http://127.0.0.1:${PORT}/health" 2>/dev/null)"
  if printf '%s' "$BODY" | grep -q '"ready":true'; then
    echo "READY on :${PORT} (pid $(cat "$PIDFILE"), pool ${POOL}) after $((i * 2))s"
    exit 0
  fi
done

echo "NOT fully ready after 200s; worker states:"
curl -s -m 5 "http://127.0.0.1:${PORT}/health" 2>/dev/null | head -c 800
echo
tail -20 "$LOG"
exit 1
