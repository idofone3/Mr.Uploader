#!/usr/bin/env bash
# DeepSeek Wrapper — ONE-script launcher.
#
#   bash run.sh          First run: installs Python deps + Chromium, then
#                        boots the API in the BACKGROUND and waits until READY.
#                        Later runs: clean restart (old process + browsers reaped).
#   bash run.sh stop     Stop the API and its browser workers.
#   bash run.sh logs     Follow the API log (Ctrl-C to exit).
#   bash run.sh 8000 2   Custom port / pool size (defaults: 8000 / 2, or .env).
#
# Credentials: deepseek_user_token.txt + deepseek_cookies.txt are read
# automatically — nothing else to configure.
set -u
cd "$(dirname "$0")" || exit 1
LOG="api.log"
PIDFILE="api.pid"

# .env supplies DS_POOL_SIZE / DS_API_KEY / ... (app.py only reads os.environ).
if [ -f .env ]; then
  set -a; . ./.env; set +a
fi

PORT="${1:-${DS_POOL_PORT:-8000}}"
POOL="${2:-${DS_POOL_SIZE:-2}}"

# ---- subcommands -----------------------------------------------------------
case "${1:-}" in
  stop)
    if [ -f "$PIDFILE" ]; then
      kill "$(cat "$PIDFILE")" 2>/dev/null && echo "stopped api (pid $(cat "$PIDFILE"))"
      rm -f "$PIDFILE"
    fi
    pkill -f "python[0-9.]* app\.py" 2>/dev/null || true
    pkill -f "user-data-dir=$(pwd)/pool_workers" 2>/dev/null || true
    echo "api + browser workers stopped."
    exit 0 ;;
  logs)
    [ -f "$LOG" ] || { echo "no $LOG yet — start first: bash run.sh"; exit 1; }
    exec tail -n 60 -f "$LOG" ;;
esac

# ---- resolve python ---------------------------------------------------------
PY=""
if [ -x ".venv/bin/python" ]; then PY="$(pwd)/.venv/bin/python"; fi
if [ -z "$PY" ]; then PY="$(command -v python3 || command -v python || true)"; fi
if [ -z "$PY" ]; then
  echo "ERROR: python3 not found on PATH."; exit 1
fi

# ---- first-run bootstrap ----------------------------------------------------
if ! "$PY" -c "import fastapi, uvicorn, playwright, pydantic" >/dev/null 2>&1; then
  echo "[run.sh] Python deps missing — installing (one-time)..."
  # Prefer a virtualenv to keep system Python clean; fall back to --user.
  if [ ! -x ".venv/bin/python" ]; then
    echo "[run.sh] creating virtualenv .venv ..."
    python3 -m venv .venv >/dev/null 2>&1 || true
  fi
  if [ -x ".venv/bin/python" ]; then
    PY="$(pwd)/.venv/bin/python"
    "$PY" -m pip install --quiet --upgrade pip >/dev/null 2>&1 || true
    "$PY" -m pip install -r requirements.txt || { echo "ERROR: pip install failed."; exit 1; }
  else
    echo "[run.sh] no venv support — installing with pip --user ..."
    "$PY" -m pip install --user -r requirements.txt || { echo "ERROR: pip install failed."; exit 1; }
  fi
fi

if ! "$PY" - <<'PYEOF' >/dev/null 2>&1
import os, sys
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    sys.exit(0 if os.path.exists(p.chromium.executable_path) else 1)
PYEOF
then
  echo "[run.sh] installing Chromium for Playwright (one-time, ~150 MB)..."
  "$PY" -m playwright install chromium || {
    echo "ERROR: playwright install chromium failed."
    echo "       If system libraries are missing run: $PY -m playwright install-deps chromium"
    exit 1; }
fi

# ---- credential sanity check ------------------------------------------------
if [ ! -s deepseek_user_token.txt ]; then
  echo "ERROR: deepseek_user_token.txt is missing/empty (login token required)."
  exit 1
fi
[ -s deepseek_cookies.txt ] && echo "[run.sh] using baked-in credentials (token + $(grep -vc '^#' deepseek_cookies.txt) cookies)."

# ---- boot in background ------------------------------------------------------
export PY
echo "[run.sh] starting API on 127.0.0.1:${PORT} (pool ${POOL}) in background..."
exec bash restart.sh "$PORT" "$POOL"
