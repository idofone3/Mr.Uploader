# DeepSeek Wrapper

OpenAI-compatible HTTP API that drives DeepSeek's web chat through a
Playwright/Chromium worker pool. Exposes `POST /v1/chat/completions`
(streaming and non-streaming) for use with OpenCode as an
`@ai-sdk/openai-compatible` provider.

⚠️ **This package contains your live DeepSeek session token and cookies**
(`deepseek_user_token.txt`, `deepseek_cookies.txt`). Treat the zip and this
folder like a password: don't re-share it, don't commit it to git. The token
expires eventually — refresh it per §2 and restart.

**TL;DR:** unzip → `bash run.sh` → OpenAI-compatible API on `127.0.0.1:8000`.

## Contents

| Path | Role |
| --- | --- |
| `app.py` | FastAPI server + Playwright worker pool |
| `run.sh` | **One-script start**: first-run install + background boot / `stop` / `logs` |
| `restart.sh` | Clean start/restart helper (used by `run.sh`) |
| `requirements.txt` | Python dependencies |
| `opencode.json` | Example OpenCode provider config |
| `deepseek_user_token.txt.example` | Token file template |
| `.env.example` | Environment variable template |
| `_verify/` | Optional test harness |

## 1. Install

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
playwright install chromium
playwright install-deps chromium   # only if system libs are missing
```

## 2. Get your DeepSeek token

1. Log in to https://chat.deepseek.com in a normal browser.
2. Open DevTools -> Console and run:

   ```js
   JSON.parse(localStorage.getItem('userToken')).value
   ```

3. Save it (one line, no quotes):

```bash
printf '%s' 'PASTE_TOKEN_HERE' > deepseek_user_token.txt
```

The token expires eventually; refresh it the same way and restart.

### 2b. Optional: pre-seed WAF cookies

If worker boots stall on the `awsWaf` challenge, hand the browser a valid
WAF token so the first navigation already passes:

1. In a logged-in browser, export cookies for `https://chat.deepseek.com`
   in Netscape `cookies.txt` format (any "Get cookies.txt" style extension).
2. Save the file as `deepseek_cookies.txt` next to `app.py` (gitignored).

Every worker calls `add_cookies()` with it before navigating. Malformed rows
are skipped individually; expired rows are dropped. See
`deepseek_cookies.txt.example` for the expected shape.

## 3. Run

One script does everything (first run installs deps + Chromium, then boots in
the background and waits until every worker is ready):

```bash
bash run.sh
# [run.sh] using baked-in credentials (token + 5 cookies).
# READY on :8000 (pid ..., pool 2) after ~10s

bash run.sh logs     # follow api.log (Ctrl-C to detach)
bash run.sh stop     # stop API + browser workers
```

Verify:

```bash
curl -s localhost:8000/health | python3 -m json.tool
curl -s localhost:8000/v1/models | python3 -m json.tool
```

Prefer the classic route? `bash restart.sh 8000 2` does a clean start/restart
without the first-run dependency bootstrap.

## 4. Environment variables

| Variable | Default | Meaning |
| --- | --- | --- |
| `DS_POOL_SIZE` | `2` | Chromium workers (concurrent sessions) |
| `DS_POOL_HOST` | `127.0.0.1` | Bind address (loopback by default; set `0.0.0.0` only with `DS_API_KEY`) |
| `DS_POOL_PORT` | `8000` | Bind port |
| `DS_HEADLESS` | `1` | `1` headless, `0` visible |
| `DS_BOOT_TIMEOUT` | `120` | Worker boot budget (s) |
| `DS_LEASE_TIMEOUT` | `180` | Wait for a free worker (s) |
| `DS_FIRST_TOKEN_TIMEOUT` | `90` | Time to first output (s) |
| `DS_STREAM_TIMEOUT` | `600` | Max stream time (s) |
| `DS_BUSY_GRACE` | `20` | Grace after text stops changing (s) |
| `DS_API_KEY` | _(unset)_ | When set, data endpoints require `Authorization: Bearer <key>` or `x-api-key` |

`restart.sh` sources `.env` automatically before starting, so put any of
these there; `python3 app.py` run directly needs them exported by hand.

## 5. OpenCode config

Merge the included `opencode.json` provider block:

```json
{
  "provider": {
    "deepseek-web": {
      "npm": "@ai-sdk/openai-compatible",
      "options": {
        "baseURL": "http://127.0.0.1:8000/v1",
        "apiKey": "not-needed"
      },
      "models": { "deepseek": { "name": "DeepSeek (web)" } }
    }
  }
}
```

## 6. API

| Method | Path | Purpose |
| --- | --- | --- |
| GET | `/health` | Pool + worker readiness |
| GET | `/v1/models` | Model list |
| POST | `/v1/chat/completions` | Chat (JSON or SSE) |
| DELETE | `/sessions/{id}` | Unpin a session |
| POST | `/sessions/{id}/reset` | Clear a session context |
| GET | `/debug/selectors/{id}` | Selector health |
| GET | `/debug/dom/{id}` | Dump live HTML |
| GET | `/debug/extract/{id}` | Reasoning/content split |
| POST | `/debug/reset/{id}` | Force a reset |

Request extras: `"stream": true` for SSE, `"web_search": true` for browsing.

## 7. Tests (optional)

```bash
python3 _verify/stream_logic_test.py
python3 _verify/sniffer_test.py
python3 _verify/toolcall_test.py
python3 _verify/boot_test.py
python3 _verify/api_checks.py     # needs a running server
```

## 8. Troubleshooting

| Symptom | Fix |
| --- | --- |
| Worker never boots / `SingletonLock` | Run `bash restart.sh` again (reaps orphans, clears locks) |
| `boot_timeout` / `awsWaf` | Token expired or WAF challenge unsolved; refresh token |
| `empty_response` | DeepSeek DOM changed; check `/debug/selectors/worker-0` |
| 503 pool busy | Raise `DS_POOL_SIZE` or reuse sessions |

## 9. Security

- `deepseek_user_token.txt` and `deepseek_cookies.txt` are live credentials;
  both are gitignored. Never commit or share them.
- Browser cookies also live in `pool_workers/worker_*/`.
- Since v6.1 the server binds `127.0.0.1` by default; export
  `DS_POOL_HOST=0.0.0.0` deliberately if you must expose it.
- Set `DS_API_KEY` to require a shared secret on every data endpoint
  (`/`, `/health` and the OpenAPI docs stay open for monitoring). OpenCode
  sends the provider `apiKey` as a Bearer header, so put the same value in
  `opencode.json` under `options.apiKey`.
- When `DS_API_KEY` is unset the API has no auth; keep it on loopback.
