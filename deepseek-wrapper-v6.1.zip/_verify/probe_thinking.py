#!/usr/bin/env python3
"""Sample the live page while a DeepThink answer is still streaming.

Writes _verify/probe_NN.html snapshots so the thinking-block markup can be
inspected for the window before the answer block exists.
"""
from __future__ import annotations

import json
import sys
import threading
import time
import urllib.request

BASE = "http://127.0.0.1:8000"
SID = "dom-probe"
OUT = []


def chat() -> None:
    body = json.dumps(
        {
            "model": "deepseek-reasoner",
            "session_id": SID,
            "stream": False,
            "messages": [
                {
                    "role": "user",
                    "content": (
                        "Explain step by step, in detail, why the sky is blue and "
                        "why sunsets are red. Think carefully before answering."
                    ),
                }
            ],
        }
    ).encode()
    req = urllib.request.Request(
        BASE + "/v1/chat/completions",
        data=body,
        headers={"content-type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=300) as resp:
            data = json.loads(resp.read().decode())
        msg = data["choices"][0]["message"]
        print("FINAL reasoning chars:", len(msg.get("reasoning_content") or ""))
        print("FINAL content   chars:", len(msg.get("content") or ""))
        print("FINAL content repr :", repr(msg.get("content"))[:200])
    except Exception as exc:  # noqa: BLE001
        print("chat failed:", exc)


def main() -> int:
    t = threading.Thread(target=chat, daemon=True)
    t.start()
    deadline = time.time() + 25
    i = 0
    while time.time() < deadline and t.is_alive():
        time.sleep(0.3)
        try:
            with urllib.request.urlopen(f"{BASE}/debug/dom/{SID}?tail=400000", timeout=5) as r:
                html = r.read().decode()
        except Exception:
            continue
        has_answer = "ds-assistant-message-main-content" in html
        n_md = html.count("ds-markdown")
        if n_md and not has_answer:
            i += 1
            path = f"_verify/probe_{i:02d}.html"
            with open(path, "w", encoding="utf-8") as fh:
                fh.write(html)
            print(f"saved {path}: ds-markdown={n_md} answer_marker=False")
            if i >= 4:
                break
    t.join(timeout=5)
    return 0


if __name__ == "__main__":
    sys.exit(main())
