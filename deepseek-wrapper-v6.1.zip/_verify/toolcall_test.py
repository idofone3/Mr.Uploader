#!/usr/bin/env python3
"""Unit tests for _extract_tool_calls.

Two input dialects must both work: the JSON protocol the wrapper asks for, and
the model's own trained tag-based tool-call markup, which it sometimes emits
instead (verified against the live model).
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app import TOOL_PROTOCOL, Tool, FunctionDef, _ToolSniffer, _extract_tool_calls  # noqa: E402

FAILURES = []


def check(name, ok, detail=""):
    print(f"{'PASS' if ok else 'FAIL'}  {name}" + ("" if ok else f"  -> {detail}"))
    if not ok:
        FAILURES.append(name)


def tool(name: str) -> Tool:
    return Tool(function=FunctionDef(name=name))


READ = tool("read")
BASH = tool("bash")
TOOLS = [READ, BASH]

# U+FF5C, the delimiter the live model wraps its tag token in.
BAR = "\uff5c"
TAG = f"<{BAR}{BAR}DSML{BAR}{BAR}"


def invoke(name: str, params: str = "", closing: str = "invoke") -> str:
    return (
        f"{TAG} invoke name=\"{name}\">\n"
        f"{params}"
        f"</{BAR}{BAR}DSML{BAR}{BAR} {closing}>\n"
    )


def param(key: str, value: str, is_str: bool = True) -> str:
    flag = "true" if is_str else "false"
    return (
        f"{TAG} parameter name=\"{key}\" string=\"{flag}\">{value}"
        f"</{BAR}{BAR}DSML{BAR}{BAR} parameter>\n"
    )


def main() -> int:
    # ------------------------------------------------------------ JSON forms
    body = '```json\n{"tool_calls": [{"name": "read", "arguments": {"path": "a.py"}}]}\n```'
    content, calls = _extract_tool_calls(body, TOOLS)
    check("fenced JSON protocol is parsed", calls is not None and calls[0]["function"]["name"] == "read", str(calls))
    check("fenced JSON is stripped from content", content == "", repr(content))
    check("fenced JSON arguments are a JSON string", json.loads(calls[0]["function"]["arguments"]) == {"path": "a.py"}, str(calls))

    bare = 'Please hold.\n{"name": "bash", "arguments": {"command": "ls"}}'
    content, calls = _extract_tool_calls(bare, TOOLS)
    check("bare JSON call is parsed", calls is not None and calls[0]["function"]["name"] == "bash", str(calls))
    check("prose before a bare call survives", content == "Please hold.", repr(content))

    wrapped = '{"tool_calls": [{"function": {"name": "read", "arguments": "{\\"path\\": \\"b\\"}"}}]}'
    _, calls = _extract_tool_calls(wrapped, TOOLS)
    check("function-wrapped JSON call is parsed", calls is not None and calls[0]["function"]["name"] == "read", str(calls))

    # ---------------------------------------------------------- native markup
    native = (
        f"{TAG} calls>\n"
        + invoke("read", param("filePath", "/tmp/opencode.json"))
        + f"</{BAR}{BAR}DSML{BAR}{BAR} calls>\n"
    )
    content, calls = _extract_tool_calls(native, TOOLS)
    check("native markup call is parsed", calls is not None and calls[0]["function"]["name"] == "read", str(calls))
    check(
        "native string parameter is kept as a string",
        json.loads(calls[0]["function"]["arguments"]) == {"filePath": "/tmp/opencode.json"},
        str(calls),
    )
    check("native markup is stripped from content", content == "", repr(content))

    native_multi = (
        f"{TAG} calls>\n"
        + invoke("read", param("filePath", "x.py"))
        + invoke("bash", param("command", "pytest -q"))
        + f"</{BAR}{BAR}DSML{BAR}{BAR} calls>\n"
    )
    content, calls = _extract_tool_calls(native_multi, TOOLS)
    check("multiple native invokes are parsed", calls is not None and len(calls) == 2, str(calls))
    check(
        "each native invoke keeps its own arguments",
        [json.loads(c["function"]["arguments"]) for c in calls] == [{"filePath": "x.py"}, {"command": "pytest -q"}],
        str(calls),
    )

    typed = (
        f"{TAG} calls>\n"
        + invoke("bash", param("command", "ls") + param("timeout", "30", is_str=False))
        + f"</{BAR}{BAR}DSML{BAR}{BAR} calls>\n"
    )
    _, calls = _extract_tool_calls(typed, TOOLS)
    check(
        'string="false" parameter becomes a JSON number',
        json.loads(calls[0]["function"]["arguments"]) == {"command": "ls", "timeout": 30},
        str(calls),
    )

    with_prose = "Let me look at the config.\n" + native
    content, calls = _extract_tool_calls(with_prose, TOOLS)
    check("prose before native markup survives", content == "Let me look at the config.", repr(content))
    check("native call found alongside prose", calls is not None, str(calls))

    # ------------------------------------------------------------- rejections
    _, calls = _extract_tool_calls(native, [BASH])
    check("an undeclared tool name is rejected", calls is None, str(calls))

    text = "There is no tool call here, just prose about JSON."
    content, calls = _extract_tool_calls(text, TOOLS)
    check("plain prose yields no calls", calls is None and content == text, f"{calls} {content!r}")

    # --------------------------------------------------------------- sniffer
    sniffer = _ToolSniffer(True)
    streamed = []
    for i in range(1, len(native) + 1):
        streamed.append(sniffer.feed(native[:i]))
    joined = "".join(streamed)
    check("native markup never leaks as prose", "DSML" not in joined and joined.strip() == "", repr(joined))

    check("protocol tells the model not to use tag syntax", "ONLY this JSON form" in TOOL_PROTOCOL, "")

    print()
    if FAILURES:
        print(f"{len(FAILURES)} CHECK(S) FAILED: {FAILURES}")
        return 1
    print("ALL TOOL-CALL CHECKS PASSED")
    return 0


if __name__ == "__main__":
    sys.exit(main())
