# Verification harness

Tests for `app.py`. Most of them exist because a specific bug was observed
against the live DeepSeek UI and would otherwise come back:

| # | Bug observed | Guarded by |
|---|---|---|
| 1 | A previous conversation still on screen was streamed as the current answer | `stream_logic_test.py` |
| 2 | `new_chat()` clicked, changed nothing, and reported success, so the next turn ran on top of the old conversation | `boot_test.py`, `leak_repro.py` |
| 3 | The "New chat" control has no `role=button`; the old selector matched zero elements, making every reset a silent no-op | `restart.sh` + `debug/selectors` |
| 4 | A searched reply never finished (`is_generating()` stays true) and hung for 400s+ | `stream_logic_test.py` |
| 5 | Tool-call payloads leaked as visible prose (`{"tool`, then the model's own tag markup) | `sniffer_test.py`, `toolcall_test.py` |
| 6 | A stale Chromium `SingletonLock` left the whole pool permanently down | `boot_test.py` |
| 7 | Code-block chrome (`Copy`, `Download`, language label) and citation markers polluted answers | `api_checks.py` + live checks |

## Browser-free tests

```bash
python3 _verify/stream_logic_test.py   # baseline gate, stop condition, busy grace
python3 _verify/sniffer_test.py        # incremental deltas + tool-call hold-back
python3 _verify/toolcall_test.py       # JSON protocol and native-markup recovery
python3 _verify/boot_test.py           # stale profile lock recovery
```

## Server-level tests

```bash
bash restart.sh 8000 2         # start the wrapper (reaps orphan Chromium)
setsid python3 _verify/stub_server.py &   # or: app.py with a fake worker pool
python3 _verify/api_checks.py          # SSE frame schema, pinning, structured errors
python3 _verify/leak_repro.py          # cross-session isolation (needs app.py + DeepSeek)
```

## Real AI SDK client

```bash
cd _verify && npm install             # ai + @ai-sdk/openai-compatible
node ai-sdk-check.mjs                 # against the stub server on :8123
BASE_URL=http://127.0.0.1:8000/v1 node ai-sdk-live.mjs   # against real DeepSeek
```

`@ai-sdk/openai-compatible` is the parser OpenCode uses and it zod-validates
every SSE frame. A frame missing a top-level `choices` array, or with a
malformed first `tool_calls` delta, surfaces here as an `error` stream part
instead of failing silently.

## End to end

```bash
opencode run --auto     -m deepseek-web/deepseek "Use the read tool to open opencode.json..."
opencode run --thinking -m deepseek-web/deepseek "How many r's in strawberry?"
# web search is per-request on the API: {"model":"deepseek","web_search":true,...}
```

## Debugging selectors

When DeepSeek ships a DOM change, start here:

```bash
curl -s localhost:8000/debug/selectors/worker-0 | python3 -m json.tool
curl -s localhost:8000/debug/extract/worker-0   | python3 -m json.tool
curl -s "localhost:8000/debug/dom/worker-0?tail=20000"
curl -s -X POST localhost:8000/debug/reset/worker-0
```

Two probes help when re-deriving selectors or wire formats:

```bash
python3 _verify/probe_thinking.py     # samples the DOM mid-DeepThink
python3 _verify/native_tool_probe.py 3  # dumps the model's tool-call output escaped
```
