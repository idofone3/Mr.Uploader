#!/usr/bin/env python3
"""Unit test for _ToolSniffer: no tool-call JSON may leak as visible prose."""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app import _ToolSniffer  # noqa: E402

FAILURES = []


def check(name: str, ok: bool, detail: str = "") -> None:
    print(f"{'PASS' if ok else 'FAIL'}  {name}" + ("" if ok else f"  -> {detail}"))
    if not ok:
        FAILURES.append(name)


def drive(snapshots, enabled=True):
    """Feed snapshots; return (streamed text, flushed tail)."""
    sniffer = _ToolSniffer(enabled)
    out = []
    for s in snapshots:
        out.append(sniffer.feed(s))
    return "".join(out), sniffer.flush()


# 1. A tool call rendered progressively must never surface as content.
payload = '{"tool_calls": [{"name": "read", "arguments": {"path": "opencode.json"}}]}'
partials = [payload[:i] for i in range(1, len(payload) + 1)]
streamed, tail = drive(partials)
check("progressive tool JSON never streamed as text", streamed.strip() == "", repr(streamed))
check("no tail released when a call is present", tail == payload or tail.strip().startswith("{"),
      repr(tail))

# 2. The exact live failure: '{"tool' must not slip through.
streamed, _ = drive(["", '{"tool', '{"tool_calls":', payload])
check('partial "{\\"tool" is withheld', streamed.strip() == "", repr(streamed))

# 3. Prose preamble is still streamed, in order and exactly once.
streamed, _ = drive(["Let", "Let me look", "Let me look that up.\n", 'Let me look that up.\n{"tool_calls": []}'])
check("prose preamble is streamed", "Let me look that up." in streamed, repr(streamed))
check("preamble not duplicated", streamed.count("Let me look that up.") == 1, repr(streamed))
check("no JSON leaked alongside prose", "tool_calls" not in streamed, repr(streamed))

# 4. No tool call after all -> the withheld tail is released intact (no loss).
plain = "Here is the answer: 42."
streamed, tail = drive([plain[:i] for i in range(1, len(plain) + 1)])
check("plain text is never lost", (streamed + tail) == plain, repr((streamed, tail)))

# 5. Short answers shorter than the hold-back window are released on flush.
streamed, tail = drive(["ok"])
check("short answer released on flush", (streamed + tail) == "ok", repr((streamed, tail)))

# 6. A fenced block is detected from its fence marker.
fenced = 'Sure:\n```json\n{"tool_calls": [{"name": "x"}]}\n```'
streamed, _ = drive([fenced[:i] for i in range(1, len(fenced) + 1)])
check("fenced payload withheld", "tool_calls" not in streamed, repr(streamed))
check("fence itself withheld", streamed.strip().endswith("Sure:"), repr(streamed))

# 7. With tools disabled, deltas are emitted verbatim and promptly.
sniffer = _ToolSniffer(False)
check("disabled sniffer streams deltas", sniffer.feed("hello") == "hello", "")
check("disabled sniffer continues delta", sniffer.feed("hello world") == " world", "")
check("disabled sniffer flush is empty", sniffer.flush() == "", "")

# 8. A rewritten DOM resyncs instead of duplicating. Text already emitted
# cannot be retracted, so the invariant is: the retained prefix appears once
# and only the changed suffix is appended.
streamed, tail = drive(["abc def", "abc XXX", "abc XXX yz"], enabled=False)
check("rewritten snapshots do not duplicate", streamed.count("abc") == 1 and streamed.endswith("XXX yz"), repr((streamed, tail)))

print()
if FAILURES:
    print(f"{len(FAILURES)} CHECK(S) FAILED: {FAILURES}")
    sys.exit(1)
print("ALL SNIFFER CHECKS PASSED")
