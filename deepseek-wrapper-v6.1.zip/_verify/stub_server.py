#!/usr/bin/env python3
"""Verification harness: serve app.py with a stubbed browser pool.

Run:  python3 _verify/stub_server.py           (listens on 127.0.0.1:8123)
It swaps the real Playwright ``Pool``/``Worker`` for deterministic fakes so the
HTTP + SSE surface can be exercised without a browser or a DeepSeek login.
"""
from __future__ import annotations

import asyncio
import contextlib
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import uvicorn

import app as appmod


class FakePage:
    async def content(self) -> str:
        return "<html><body><div class='ds-markdown'>stub</div></body></html>"


class StubWorker:
    def __init__(self, wid: int, *_: object, **__: object) -> None:
        self.wid = wid
        self.ready = True
        self.error = None
        self.session_id = None
        self.last_used = 0.0
        self.lock = asyncio.Lock()
        self.last_prompt = None
        self._fresh = True
        self._plan: list[dict[str, str]] = []
        # Mirror the real Worker's toggle caches, which /debug/extract reports.
        self._deep_think = False
        self._search = False
        self.page = FakePage()

    async def start(self) -> None: ...
    async def stop(self) -> None: ...

    async def reset(self) -> None:
        self.last_prompt = None
        self._fresh = True

    async def count(self) -> int:
        return 0

    async def submit(self, prompt: str) -> None:
        self._plan = self._plan_for(prompt)

    @staticmethod
    def _plan_for(prompt: str) -> list[dict[str, str]]:
        if "NEEDTOOL" in prompt:
            return [
                {"reasoning": "", "content": '```json\n{"tool_calls": [{"name": "get_weather"'},
                {"reasoning": "", "content": '```json\n{"tool_calls": [{"name": "get_weather", "arguments": {"city": "Paris"}}]}\n```'},
            ]
        if "THINK" in prompt:
            return [
                {"reasoning": "Let me think", "content": ""},
                {"reasoning": "Let me think about it.", "content": ""},
                {"reasoning": "Let me think about it.", "content": "The answer"},
                {"reasoning": "Let me think about it.", "content": "The answer is 42."},
            ]
        last = prompt.strip().splitlines()[-1] if prompt.strip() else ""
        # Proves that replayed assistant thinking reaches the model prompt.
        marker = "[replayed-reasoning] " if "Assistant reasoning:" in prompt else ""
        return [
            {"reasoning": "", "content": "Echo: "},
            {"reasoning": "", "content": f"Echo: {marker}{last}"},
        ]

    async def begin(self, prompt: str):
        self.last_prompt = prompt
        return prompt, 0, {"reasoning": "", "content": ""}

    async def stream(self, before_count: int = 0, baseline: object = None, **_kw: object):
        for snap in self._plan:
            await asyncio.sleep(0.01)
            yield snap

    async def snapshot(self) -> dict[str, str]:
        return self._plan[-1] if self._plan else {"reasoning": "", "content": ""}

    async def set_deep_think(self, enabled: bool) -> bool:
        self._deep_think = enabled
        return enabled

    async def set_web_search(self, enabled: bool) -> bool:
        self._search = enabled
        return enabled

    async def has_composer(self) -> bool:
        return True

    async def is_generating(self) -> bool:
        return False


class StubPool(appmod.Pool):
    async def start(self) -> None:
        self.pw = None
        for i in range(self.size):
            worker = StubWorker(i)
            self.workers.append(worker)  # type: ignore[arg-type]
            self.free.put_nowait(worker)  # type: ignore[arg-type]

    async def stop(self) -> None:
        for worker in self.workers:
            with contextlib.suppress(Exception):
                await worker.stop()


appmod.Pool = StubPool  # type: ignore[misc]
appmod.POOL_SIZE = int(os.environ.get("DS_POOL_SIZE", "2"))

if __name__ == "__main__":
    uvicorn.run(appmod.app, host="127.0.0.1", port=8123, log_level="warning")
