#!/usr/bin/env python3
"""Cross-session isolation stress test.

With a 2-worker pool and more sessions than workers, eviction forces each tab to
be reused. Every session must get its own answer and never another session's
text (that leak is what the baseline guard and the verified reset exist for).
"""
from __future__ import annotations

import concurrent.futures as cf
import json
import sys
import urllib.request

BASE = "http://127.0.0.1:8000"
MARKERS = [
    "ZEBRAQUARTZ",
    "MANGOTANGO",
    "PAPAYAORBIT",
    "KIWIVECTOR",
    "LEMONPULSE",
    "MELONZEPHYR",
]
FAILURES: list[str] = []


def check(name: str, ok: bool, detail: str = "") -> None:
    print(f"{'PASS' if ok else 'FAIL'}  {name}" + ("" if ok else f"  -> {detail}"))
    if not ok:
        FAILURES.append(name)


def post(body: dict, timeout: int = 400) -> dict:
    req = urllib.request.Request(
        BASE + "/v1/chat/completions",
        data=json.dumps(body).encode(),
        headers={"content-type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode())


def stream_text(body: dict, timeout: int = 400) -> tuple[str, str]:
    """Return (content, reasoning) accumulated from the SSE stream."""
    req = urllib.request.Request(
        BASE + "/v1/chat/completions",
        data=json.dumps(body).encode(),
        headers={"content-type": "application/json"},
        method="POST",
    )
    content, reasoning = [], []
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        for raw in resp:
            line = raw.decode(errors="replace").strip()
            if not line.startswith("data:"):
                continue
            payload = line[5:].strip()
            if payload == "[DONE]":
                break
            frame = json.loads(payload)
            for choice in frame.get("choices", []):
                delta = choice.get("delta", {})
                if delta.get("content"):
                    content.append(delta["content"])
                if delta.get("reasoning_content"):
                    reasoning.append(delta["reasoning_content"])
    return "".join(content), "".join(reasoning)


def own_only(i: int, text: str) -> bool:
    mine = MARKERS[i] in text
    others = [m for j, m in enumerate(MARKERS) if j != i and m in text]
    return mine and not others


def run_sequential() -> None:
    print("--- sequential reuse (forced eviction) ---")
    for i, marker in enumerate(MARKERS):
        model = "deepseek-reasoner" if i % 2 else "deepseek-chat"
        data = post(
            {
                "model": model,
                "session_id": f"iso-{i}",
                "messages": [
                    {
                        "role": "user",
                        "content": f"Repeat back this exact word and nothing else: {marker}",
                    }
                ],
            }
        )
        text = (data["choices"][0]["message"].get("content") or "") + (
            data["choices"][0]["message"].get("reasoning_content") or ""
        )
        check(f"session iso-{i} ({model}) got only its own text", own_only(i, text), repr(text)[:220])

    print("--- streaming variant ---")
    for i, marker in enumerate(MARKERS[:3]):
        txt, reason = stream_text(
            {
                "model": "deepseek-reasoner",
                "session_id": f"isostream-{i}",
                "stream": True,
                "messages": [
                    {
                        "role": "user",
                        "content": f"Repeat back this exact word and nothing else: {marker}",
                    }
                ],
            }
        )
        check(f"stream session isostream-{i} got only its own text", own_only(i, txt + reason), repr(txt)[:220])


def run_concurrent() -> None:
    print("--- concurrent sessions ---")

    def one(i: int):
        marker = MARKERS[i]
        data = post(
            {
                "model": "deepseek-chat",
                "session_id": f"conc-{i}",
                "messages": [
                    {
                        "role": "user",
                        "content": f"Repeat back this exact word and nothing else: {marker}",
                    }
                ],
            }
        )
        text = data["choices"][0]["message"].get("content") or ""
        return i, text

    with cf.ThreadPoolExecutor(max_workers=2) as pool:
        results = list(pool.map(one, range(len(MARKERS))))
    for i, text in results:
        check(f"concurrent session conc-{i} got only its own text", own_only(i, text), repr(text)[:220])


def main() -> int:
    run_sequential()
    run_concurrent()
    print()
    if FAILURES:
        print(f"{len(FAILURES)} CHECK(S) FAILED: {FAILURES}")
        return 1
    print("ALL CROSS-SESSION ISOLATION CHECKS PASSED")
    return 0


if __name__ == "__main__":
    sys.exit(main())
