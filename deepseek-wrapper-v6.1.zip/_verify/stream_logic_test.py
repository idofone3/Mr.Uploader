#!/usr/bin/env python3
"""Unit-level test for Worker.stream's baseline gate and stop condition.

The live bug this guards against: a previous conversation still on screen was
streamed as the current answer's content. It needs no browser - the page-facing
methods are replaced with a scripted sequence.
"""
from __future__ import annotations

import asyncio
import sys
from pathlib import Path
from typing import Any, Dict, List

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import app as appmod

FAILURES: List[str] = []


def check(name: str, ok: bool, detail: str = "") -> None:
    print(f"{'PASS' if ok else 'FAIL'}  {name}" + ("" if ok else f"  -> {detail}"))
    if not ok:
        FAILURES.append(name)


class ScriptedWorker(appmod.Worker):
    """A Worker whose page-facing calls replay a fixed script."""

    def __init__(self, snapshots, counts, generating) -> None:
        super().__init__(0, Path("/tmp/unused"), None)
        self.ready = True
        self._snapshots = list(snapshots)
        self._counts = list(counts)
        self._generating = list(generating)
        self._i = 0
        self._last = {"reasoning": "", "content": ""}

    # snapshot() advances the script; count()/is_generating() read the same step
    # so every poll observes one consistent triple.
    async def snapshot(self) -> Dict[str, str]:
        if self._i < len(self._snapshots):
            self._last = self._snapshots[self._i]
        self._i += 1
        return self._last

    @property
    def _step(self) -> int:
        return max(0, self._i - 1)

    async def count(self) -> int:
        return self._counts[min(self._step, len(self._counts) - 1)]

    async def is_generating(self) -> bool:
        return self._generating[min(self._step, len(self._generating) - 1)]


async def run(snapshots, counts, generating, before_count, baseline, **kwargs):
    worker = ScriptedWorker(snapshots, counts, generating)
    out: List[Dict[str, str]] = []
    kwargs.setdefault("timeout_s", 5.0)

    async for snap in worker.stream(before_count, baseline, tick=0.0, **kwargs):
        out.append(dict(snap))

    return out


async def main() -> int:
    # 1. A stale previous answer on screen must never be emitted.
    stale = {"reasoning": "", "content": "17 x 23 = 391"}
    fresh = {"reasoning": "", "content": "41 and 43."}
    out = await run(
        snapshots=[stale, stale, fresh, fresh, fresh, fresh, fresh, fresh, fresh],
        counts=[1, 1, 2, 2, 2, 2, 2, 2, 2],
        generating=[False, False, True, True, False, False, False, False, False],
        before_count=1,
        baseline=stale,
        stable_ticks=3,
    )
    check("stale baseline is never streamed", all(o != stale for o in out), str(out))
    check("new answer is streamed", any(o["content"] == "41 and 43." for o in out), str(out))
    check("last emitted snapshot is the new answer", out[-1]["content"] == "41 and 43.", str(out))

    # 2. Text identical to the baseline is never emitted, even if the bubble
    #    count grows: the answer must be *different* from what was already on
    #    screen. The turn gives up on the first-token budget instead of leaking.
    same = {"reasoning": "", "content": "same answer"}
    out = await run(
        snapshots=[same] * 8,
        counts=[1, 2, 2, 2, 2, 2, 2, 2],
        generating=[False, True, False, False, False, False, False, False],
        before_count=1,
        baseline=same,
        stable_ticks=2,
        first_token_s=0.0,
    )
    check("a stale identical answer is never emitted", out == [], str(out))

    # 3. Reasoning then content, with the reasoning held back until the end.
    r1 = {"reasoning": "step one", "content": ""}
    r2 = {"reasoning": "step one done", "content": "final"}
    out = await run(
        snapshots=[r1, r1, r2, r2, r2, r2, r2, r2],
        counts=[0, 1, 1, 1, 1, 1, 1, 1],
        generating=[False, True, True, False, False, False, False, False],
        before_count=0,
        baseline={"reasoning": "", "content": ""},
        stable_ticks=2,
    )
    check("reasoning is emitted incrementally", out[0]["reasoning"] == "step one", str(out))
    check("content follows reasoning", out[-1]["content"] == "final", str(out))

    # 4. A page that keeps looking busy must not be declared finished early.
    t1 = {"reasoning": "", "content": "partial"}
    t2 = {"reasoning": "", "content": "partial and more"}
    out = await run(
        snapshots=[t1, t1, t1, t1, t2, t2, t2, t2, t2, t2, t2, t2],
        counts=[1] * 12,
        generating=[True, True, True, True, True, True, False, False, False, False, False, False],
        before_count=0,
        baseline={"reasoning": "", "content": ""},
        stable_ticks=2,
    )
    check("does not finish while the UI says generating", out[-1]["content"] == "partial and more", str(out))

    # 5. Silence (no reply at all) gives up on the first-token budget.
    out = await run(
        snapshots=[{"reasoning": "", "content": ""}] * 50,
        counts=[0] * 50,
        generating=[False] * 50,
        before_count=0,
        baseline={"reasoning": "", "content": ""},
        stable_ticks=2,
        first_token_s=0.0,
    )
    check("silence yields nothing", out == [], str(out))

    # 6. The hard timeout is respected.
    loop = asyncio.get_running_loop()
    started = loop.time()
    out = await run(
        snapshots=[{"reasoning": "", "content": "x"}] * 400,
        counts=[1] * 400,
        generating=[True] * 400,
        before_count=0,
        baseline={"reasoning": "", "content": ""},
        stable_ticks=2,
        timeout_s=0.5,
    )
    check("timeout_s bounds the poll loop", loop.time() - started < 5, str(out))

    # 7. A permanently busy-looking UI must still finish once the text is stable.
    #    This is the web-search case: DeepSeek keeps a busy control around long
    #    after the answer has stopped changing.
    final_snap = {"reasoning": "", "content": "final answer"}
    out = await run(
        snapshots=[final_snap] * 60,
        counts=[1] * 60,
        generating=[True] * 60,
        before_count=0,
        baseline={"reasoning": "", "content": ""},
        stable_ticks=2,
        busy_grace=0.0,
        timeout_s=5.0,
    )
    check(
        "a forever-busy UI still finishes after the grace",
        bool(out) and out[-1]["content"] == "final answer",
        str(out),
    )

    print()
    if FAILURES:
        print(f"{len(FAILURES)} CHECK(S) FAILED: {FAILURES}")
        return 1
    print("ALL STREAM-LOGIC CHECKS PASSED")
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
