#!/usr/bin/env python3
"""Capture the model's native (non-JSON) tool-call output, byte-exact.

DeepSeek sometimes answers with its own trained tool-call markup instead of the
JSON protocol the wrapper asks for. This dumps those bytes escaped so the
parser can be written against the real thing.
"""
from __future__ import annotations

import json
import sys
import urllib.request

TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "read",
            "description": "Read a file from disk",
            "parameters": {
                "type": "object",
                "properties": {"filePath": {"type": "string"}},
                "required": ["filePath"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "bash",
            "description": "Run a shell command",
            "parameters": {
                "type": "object",
                "properties": {"command": {"type": "string"}},
                "required": ["command"],
            },
        },
    },
]

SYSTEM = (
    "You are opencode, an interactive CLI tool that helps users with software "
    "engineering tasks. Use the tools available to you. When you need to inspect "
    "a file, call the read tool with the filePath argument."
)


def run(session: str) -> str:
    body = {
        "model": "deepseek-chat",
        "session_id": session,
        "tools": TOOLS,
        "tool_choice": "auto",
        "messages": [
            {"role": "system", "content": SYSTEM},
            {
                "role": "user",
                "content": "Read the file opencode.json and show me the baseURL value.",
            },
        ],
    }
    req = urllib.request.Request(
        "http://127.0.0.1:8000/v1/chat/completions",
        data=json.dumps(body).encode(),
        headers={"content-type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=400) as resp:
        data = json.loads(resp.read().decode())
    choice = data["choices"][0]
    msg = choice["message"]
    return json.dumps(
        {
            "finish_reason": choice["finish_reason"],
            "tool_calls": msg.get("tool_calls"),
            "content_escaped": (msg.get("content") or "").encode("unicode_escape").decode("ascii"),
            "content_len": len(msg.get("content") or ""),
        },
        indent=2,
    )


if __name__ == "__main__":
    for i in range(int(sys.argv[1]) if len(sys.argv) > 1 else 3):
        print(f"===== attempt {i} =====")
        try:
            print(run(f"native-probe-{i}"))
        except Exception as exc:  # noqa: BLE001
            print("failed:", exc)
