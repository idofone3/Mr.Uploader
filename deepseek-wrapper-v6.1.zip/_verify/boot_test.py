#!/usr/bin/env python3
"""Unit test for worker boot recovery from a stale Chromium profile lock.

Observed in practice: after the wrapper is killed, the next start fails with
"Failed to create .../SingletonLock: File exists (17)" and every worker stays
down. The pool must clear the lock and retry, but only when no live Chromium
owns the profile.
"""
from __future__ import annotations

import asyncio
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import app as appmod  # noqa: E402

FAILURES = []
SINGLETON_MSG = (
    "BrowserType.launch_persistent_context: Failed to create a ProcessSingleton "
    "for your profile directory.\n  - [err] Failed to create "
    "/profile/SingletonLock: File exists (17)"
)


def check(name, ok, detail=""):
    print(f"{'PASS' if ok else 'FAIL'}  {name}" + ("" if ok else f"  -> {detail}"))
    if not ok:
        FAILURES.append(name)


class FakePage:
    async def goto(self, *a, **k):
        return None


class FakeCtx:
    def __init__(self) -> None:
        self.pages = [FakePage()]
        self.closed = False

    async def add_init_script(self, *a, **k):
        return None

    async def close(self):
        self.closed = True


class FakeChromium:
    def __init__(self, failures: int) -> None:
        self.failures = failures
        self.launches = 0

    async def launch_persistent_context(self, *a, **k):
        self.launches += 1
        if self.launches <= self.failures:
            raise RuntimeError(SINGLETON_MSG)
        return FakeCtx()


class FakePW:
    def __init__(self, failures: int) -> None:
        self.chromium = FakeChromium(failures)


class TestWorker(appmod.Worker):
    """Worker that skips the network-dependent parts of start()."""

    async def _wait_for_shell(self) -> None:
        return None


async def boot(failures: int, profile: Path, in_use: bool = False):
    worker = TestWorker(0, profile, FakePW(failures))
    if in_use:
        worker._profile_in_use = lambda: True  # type: ignore[method-assign]
    (profile / "SingletonLock").symlink_to("somehost-4242")
    (profile / "SingletonCookie").write_text("x")
    error = None
    try:
        await worker.start()
    except Exception as exc:  # noqa: BLE001
        error = exc
    return worker, error


async def main() -> int:
    with tempfile.TemporaryDirectory() as tmpdir:
        profile = Path(tmpdir) / "worker_0"
        profile.mkdir()

        worker, error = await boot(1, profile)
        check("boot succeeds after clearing a stale lock", error is None and worker.ready, repr(error))
        check("the launch was retried exactly once", worker.pw.chromium.launches == 2, str(worker.pw.chromium.launches))
        # SingletonLock is a symlink, so exists() is False when its target is
        # gone; is_symlink() is the assertion that actually means "removed".
        check("SingletonLock removed", not (profile / "SingletonLock").is_symlink(), "")
        check("SingletonCookie removed", not (profile / "SingletonCookie").exists(), "")

    with tempfile.TemporaryDirectory() as tmpdir:
        profile = Path(tmpdir) / "worker_0"
        profile.mkdir()
        worker, error = await boot(2, profile)
        check("a second failure surfaces as an error", error is not None and not worker.ready, repr(error))

    with tempfile.TemporaryDirectory() as tmpdir:
        profile = Path(tmpdir) / "worker_0"
        profile.mkdir()
        # A live Chromium owns the profile: the lock must be left alone.
        worker, error = await boot(1, profile, in_use=True)
        check("lock is preserved while the profile is in use", error is not None, repr(error))
        check("in-use profile keeps its lock", (profile / "SingletonLock").is_symlink(), "")
        check("in-use profile is not retried", worker.pw.chromium.launches == 1, str(worker.pw.chromium.launches))

    with tempfile.TemporaryDirectory() as tmpdir:
        profile = Path(tmpdir) / "worker_0"
        profile.mkdir()
        # Non-singleton launch failures must not be masked.
        class UnrelatedChromium(FakeChromium):
            async def launch_persistent_context(self, *a, **k):
                self.launches += 1
                raise RuntimeError("some unrelated browser failure")

        pw = FakePW(0)
        pw.chromium = UnrelatedChromium(0)
        worker = TestWorker(0, profile, pw)
        error = None
        try:
            await worker.start()
        except Exception as exc:  # noqa: BLE001
            error = exc
        check("unrelated launch failures are not swallowed", error is not None and "unrelated" in str(error), repr(error))
        check("unrelated failures are not retried", pw.chromium.launches == 1, str(pw.chromium.launches))

    print()
    if FAILURES:
        print(f"{len(FAILURES)} CHECK(S) FAILED: {FAILURES}")
        return 1
    print("ALL BOOT/RECOVERY CHECKS PASSED")
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
