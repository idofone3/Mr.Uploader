#!/usr/bin/env python3
"""Protocol + robustness checks against the stub server on 127.0.0.1:8123."""
from __future__ import annotations

import concurrent.futures as cf
import json
import sys
import urllib.error
import urllib.request

BASE = "http://127.0.0.1:8123"
FAILURES: list[str] = []


def check(name: str, ok: bool, detail: str = "") -> None:
    print(f"{'PASS' if ok else 'FAIL'}  {name}" + ("" if ok else f"  -> {detail}"))
    if not ok:
        FAILURES.append(name)


def post(path: str, body: dict, headers: dict | None = None) -> tuple[int, str]:
    req = urllib.request.Request(
        BASE + path,
        data=json.dumps(body).encode(),
        headers={"content-type": "application/json", **(headers or {})},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            return resp.status, resp.read().decode()
    except urllib.error.HTTPError as exc:
        return exc.code, exc.read().decode()


def get(path: str) -> tuple[int, str]:
    try:
        with urllib.request.urlopen(BASE + path, timeout=30) as resp:
            return resp.status, resp.read().decode()
    except urllib.error.HTTPError as exc:
        return exc.code, exc.read().decode()


def frames(body: str) -> list[dict]:
    out = []
    for line in body.splitlines():
        line = line.strip()
        if not line.startswith("data:"):
            continue
        payload = line[5:].strip()
        if payload == "[DONE]":
            out.append({"_done": True})
            continue
        out.append(json.loads(payload))
    return out


def main() -> int:
    # ---------------------------------------------------- frame schema -------
    status, body = post(
        "/v1/chat/completions",
        {
            "model": "deepseek-reasoner",
            "messages": [{"role": "user", "content": "THINK about life"}],
            "stream": True,
        },
    )
    parsed = frames(body)
    check("stream returns 200", status == 200, str(status))
    data_frames = [f for f in parsed if not f.get("_done")]
    check("every frame parses as JSON", len(data_frames) > 2, body[:200])
    check(
        "every frame has a top-level choices array",
        all(isinstance(f.get("choices"), list) for f in data_frames),
        str([f for f in data_frames if not isinstance(f.get("choices"), list)][:1]),
    )
    check(
        "every frame declares object=chat.completion.chunk",
        all(f.get("object") == "chat.completion.chunk" for f in data_frames),
        "",
    )
    check("stream ends with [DONE]", parsed[-1].get("_done") is True, str(parsed[-1]))
    finish_idx = [
        i
        for i, f in enumerate(data_frames)
        if any(c.get("finish_reason") for c in f["choices"])
    ]
    usage_idx = [i for i, f in enumerate(data_frames) if f.get("usage") is not None]
    check(
        "exactly one finish_reason frame and one usage frame",
        len(finish_idx) == 1 and len(usage_idx) == 1,
        str((finish_idx, usage_idx)),
    )
    check(
        "finish_reason frame immediately precedes the usage frame",
        bool(finish_idx) and bool(usage_idx) and usage_idx[0] == finish_idx[0] + 1,
        str((finish_idx, usage_idx)),
    )
    check(
        "usage frame keeps choices present (empty)",
        data_frames[-1].get("choices") == [] and "usage" in data_frames[-1],
        json.dumps(data_frames[-1]),
    )
    check(
        "delta.role is only ever 'assistant' or absent",
        all(
            c.get("delta", {}).get("role") in (None, "assistant", "")
            for f in data_frames
            for c in f["choices"]
        ),
        "",
    )
    check(
        "tool-call deltas always carry a function object",
        all(
            "function" in tc
            for f in data_frames
            for c in f["choices"]
            for tc in (c.get("delta", {}).get("tool_calls") or [])
        ),
        "",
    )

    # tool-call stream shape
    status, body = post(
        "/v1/chat/completions",
        {
            "model": "deepseek-chat",
            "messages": [{"role": "user", "content": "NEEDTOOL paris"}],
            "stream": True,
            "tools": [
                {
                    "type": "function",
                    "function": {"name": "get_weather", "parameters": {"type": "object"}},
                }
            ],
        },
    )
    tframes = [f for f in frames(body) if not f.get("_done")]
    tc_deltas = [
        tc
        for f in tframes
        for c in f["choices"]
        for tc in (c.get("delta", {}).get("tool_calls") or [])
    ]
    check("tool-call chunk emitted", len(tc_deltas) == 1, json.dumps(tc_deltas))
    check(
        "first tool-call delta carries name and id",
        bool(tc_deltas) and tc_deltas[0].get("function", {}).get("name") == "get_weather"
        and bool(tc_deltas[0].get("id")),
        json.dumps(tc_deltas[:1]),
    )
    check(
        "no raw tool JSON streamed as content",
        "tool_calls" not in "".join(
            c.get("delta", {}).get("content") or ""
            for f in tframes
            for c in f["choices"]
        ),
        "",
    )
    check(
        'finish_reason "tool_calls"',
        any(
            c.get("finish_reason") == "tool_calls" for f in tframes for c in f["choices"]
        ),
        "",
    )

    # ---------------------------------------------------- session pinning ----
    session = {"session_id": "pin-test", "messages": [{"role": "user", "content": "hi"}]}
    seen: set[int] = set()
    for _ in range(3):
        status, body = post("/v1/chat/completions", dict(session))
        check("sequential request on pinned session succeeds", status == 200, body[:150])
        _, health = get("/health")
        stats = json.loads(health)
        bound = [
            w["id"]
            for w in stats["workers"]
            if w.get("session_id") == "pin-test"
        ]
        check("session is bound to exactly one worker", len(bound) == 1, json.dumps(stats))
        seen.update(bound)
    check("session stays on the same worker across requests", len(seen) == 1, str(seen))

    # concurrent hits on one session must not corrupt each other
    def hit(i: int) -> tuple[int, str]:
        return post(
            "/v1/chat/completions",
            {
                "session_id": "pin-test",
                "messages": [{"role": "user", "content": f"hi {i}"}],
            },
        )

    with cf.ThreadPoolExecutor(max_workers=5) as ex:
        results = list(ex.map(hit, range(5)))
    check(
        "5 concurrent requests to one session all succeed",
        all(status == 200 for status, _ in results),
        str([s for s, _ in results]),
    )
    check(
        "concurrent responses are not cross-contaminated",
        all(f"Echo: User: hi {i}" in body for i, (_, body) in enumerate(results)),
        str([b[:120] for _, b in results]),
    )

    # more sessions than workers -> eviction must stay correct
    def hit_session(i: int) -> tuple[int, str]:
        return post(
            "/v1/chat/completions",
            {
                "session_id": f"multi-{i}",
                "messages": [{"role": "user", "content": f"job {i}"}],
            },
        )

    with cf.ThreadPoolExecutor(max_workers=4) as ex:
        results = list(ex.map(hit_session, range(4)))
    check(
        "4 concurrent sessions on a 2-worker pool all succeed",
        all(status == 200 for status, _ in results),
        str([s for s, _ in results]),
    )
    _, health = get("/health")
    stats = json.loads(health)
    check(
        "no session outnumbers the pool",
        len(stats["sessions"]) <= stats["pool_size"],
        json.dumps(stats["sessions"]),
    )
    check(
        "every session maps to a distinct worker",
        len({w["id"] for w in stats["workers"] if w.get("session_id")}) == len(stats["sessions"]),
        json.dumps(stats),
    )
    check("health reports ready", stats["ready"] is True, health[:200])

    # ---------------------------------------------------- structured errors --
    status, body = post("/v1/chat/completions", {"model": "deepseek-chat", "messages": []})
    check("empty messages -> 400", status == 400, f"{status} {body[:150]}")
    check(
        "400 body uses the OpenAI error envelope",
        isinstance(json.loads(body).get("error"), dict)
        and "message" in json.loads(body)["error"],
        body[:200],
    )

    status, body = post("/v1/chat/completions", {"model": "x"})
    check("missing messages -> 400 not 500", status == 400, f"{status} {body[:150]}")

    status, body = get("/debug/dom/does-not-exist")
    check("unknown session -> 404", status == 404, f"{status} {body[:150]}")
    check(
        "404 body uses the OpenAI error envelope",
        isinstance(json.loads(body).get("error"), dict),
        body[:200],
    )

    status, body = get("/debug/extract/worker-0")
    check("debug extract works for worker shorthand", status == 200, f"{status} {body[:150]}")
    check(
        "debug extract returns the reasoning/content split",
        set(json.loads(body)) >= {"reasoning", "content", "textarea_present", "generating"},
        body[:200],
    )

    status, body = get("/debug/dom/worker-0")
    check("debug dom returns html", status == 200 and "<html" in body, f"{status} {body[:80]}")

    status, body = get("/v1/no-such-route")
    check("unknown route -> 404", status == 404, f"{status} {body[:120]}")

    status, body = post("/v1/chat/completions", {"messages": [{"role": "user", "content": "hi"}]})
    check("default model works without an explicit model field", status == 200, body[:150])

    print()
    if FAILURES:
        print(f"{len(FAILURES)} CHECK(S) FAILED: {FAILURES}")
        return 1
    print("ALL PROTOCOL / CONCURRENCY CHECKS PASSED")
    return 0


if __name__ == "__main__":
    sys.exit(main())
