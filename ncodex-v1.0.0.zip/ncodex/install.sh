#!/usr/bin/env bash
# Install ncodex as a global command.
#   bash install.sh          -> tries /usr/local/bin, then ~/.local/bin
set -euo pipefail
cd "$(dirname "$0")"
NAME=ncodex

install_to() {
  mkdir -p "$1" 2>/dev/null || true
  install -m 0755 ncodex.py "$1/$NAME"
  echo "installed -> $1/$NAME"
  command -v "$NAME" >/dev/null 2>&1 && echo "'$NAME' is on PATH" || {
    case ":$PATH:" in
      *":$1:"*) ;;
      *) echo "NOTE: add to PATH:  echo 'export PATH=\"$1:\$PATH\"' >> ~/.bashrc && source ~/.bashrc" ;;
    esac
  }
}

if [ -w /usr/local/bin ]; then
  install_to /usr/local/bin
elif command -v sudo >/dev/null 2>&1 && sudo -n true 2>/dev/null; then
  sudo install -m 0755 ncodex.py /usr/local/bin/$NAME && echo "installed -> /usr/local/bin/$NAME"
else
  install_to "$HOME/.local/bin"
fi

echo "run it:  $NAME        (or: $NAME -p 'summarise this repo')"
