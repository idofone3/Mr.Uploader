#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ncodex — an OpenCode-style terminal coding agent for OpenAI-compatible endpoints.

Built for the DeepSeek web wrapper (default endpoint: https://deepu.niggahunter.qzz.io)
but works with any /v1/chat/completions server. Stdlib only — no pip installs.

  ncodex                    interactive session
  ncodex -p "fix the bug"   one-shot print mode
  ncodex --yolo             auto-approve every tool action
  (inside a session) /help  all commands

Tools the agent may call: bash, read_file, write_file, edit_file,
list_dir, glob, grep. Write-ish actions ask for approval unless --yolo.
"""

import argparse
import datetime
import glob as globmod
import json
import os
import platform
import re
import subprocess
import sys
import urllib.error
import urllib.request
from pathlib import Path

VERSION = "1.0.0"
DEFAULT_BASE = os.environ.get("NCODEX_BASE", "https://deepu.niggahunter.qzz.io")
IGNORE_DIRS = {".git", "node_modules", "__pycache__", ".venv", "venv",
               "pool_workers", ".ncodex", ".mypy_cache", ".pytest_cache"}
TO_MODEL_CAP = 8000        # max chars of tool output fed back to the model
HISTORY_FILE = Path.home() / ".ncodex_history"
SESSION_DIR = Path.home() / ".ncodex" / "sessions"


# ---------------------------------------------------------------- ANSI ----
class _C:
    def __init__(self, on):
        if on:
            self.reset = "\x1b[0m";  self.bold = "\x1b[1m";   self.dim = "\x1b[2m"
            self.red = "\x1b[31m";   self.green = "\x1b[32m"; self.yellow = "\x1b[33m"
            self.blue = "\x1b[34m";  self.magenta = "\x1b[35m"; self.cyan = "\x1b[36m"
            self.gray = "\x1b[90m"
        else:
            for k in ("reset bold dim red green yellow blue magenta cyan gray".split()):
                setattr(self, k, "")

C = _C(sys.stdout.isatty() and os.environ.get("NO_COLOR") is None and sys.platform != "win32")


def clip(text, n=1500):
    text = text.rstrip()
    return text if len(text) <= n else text[:n] + f"  …[+{len(text) - n} chars]"


class ApiError(Exception):
    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


# ------------------------------------------------------------- client ----
class Client:
    """Thin streaming client for /v1/chat/completions (urllib, stdlib only)."""

    def __init__(self, base, key=None, model=None, timeout=600):
        self.base = base.rstrip("/")
        self.key = key
        self.model = model            # None => omit 'model' (server default)
        self.timeout = timeout

    @property
    def headers(self):
        h = {"Content-Type": "application/json", "Accept": "text/event-stream",
             "User-Agent": f"ncodex/{VERSION}"}   # python-urllib default UA gets 403 at some edges
        if self.key:
            h["Authorization"] = f"Bearer {self.key}"
        return h

    def models(self):
        req = urllib.request.Request(self.base + "/v1/models", headers=self.headers)
        try:
            with urllib.request.urlopen(req, timeout=20) as r:
                data = json.loads(r.read().decode("utf-8", "replace"))
        except urllib.error.HTTPError as e:
            raise ApiError(f"HTTP {e.code} listing models", e.code)
        except urllib.error.URLError as e:
            raise ApiError(f"cannot reach {self.base}: {e.reason}", None)
        return [m.get("id", "?") for m in data.get("data", [])]

    def chat(self, messages, tools=None, on_content=None, on_reasoning=None):
        """Stream one assistant turn. Returns an assistant message dict with
        optional 'reasoning_content' and 'tool_calls' (fully assembled)."""
        payload = {"messages": messages, "stream": True}
        if self.model:
            payload["model"] = self.model
        if tools:
            payload["tools"] = tools
            payload["tool_choice"] = "auto"

        req = urllib.request.Request(
            self.base + "/v1/chat/completions",
            data=json.dumps(payload).encode("utf-8"),
            headers=self.headers, method="POST")

        try:
            resp = urllib.request.urlopen(req, timeout=self.timeout)
        except urllib.error.HTTPError as e:
            body = ""
            try:
                body = e.read().decode("utf-8", "replace")[:300]
            except Exception:
                pass
            hint = ""
            if e.code in (401, 403):
                hint = "  (auth required — set NCODEX_KEY env or pass --key KEY)"
            raise ApiError(f"HTTP {e.code}: {body or e.reason}{hint}", e.code)
        except urllib.error.URLError as e:
            raise ApiError(f"cannot reach {self.base}: {e.reason}", None)
        except OSError as e:
            raise ApiError(f"connection error: {e}", None)

        content_parts, reasoning_parts, tool_slots = [], [], {}
        finish = None
        with resp:
            for raw in resp:
                line = raw.decode("utf-8", "replace").strip()
                if not line.startswith("data:"):
                    continue
                data = line[5:].strip()
                if data == "[DONE]":
                    break
                try:
                    chunk = json.loads(data)
                except json.JSONDecodeError:
                    continue
                for ch in chunk.get("choices") or []:
                    delta = ch.get("delta") or {}
                    rc = delta.get("reasoning_content")
                    if rc:
                        reasoning_parts.append(rc)
                        if on_reasoning:
                            on_reasoning(rc)
                    txt = delta.get("content")
                    if txt:
                        content_parts.append(txt)
                        if on_content:
                            on_content(txt)
                    for tcd in delta.get("tool_calls") or []:
                        idx = tcd.get("index", 0)
                        slot = tool_slots.setdefault(
                            idx, {"id": "", "type": "function",
                                  "function": {"name": "", "arguments": ""}})
                        if tcd.get("id"):
                            slot["id"] = tcd["id"]
                        fn = tcd.get("function") or {}
                        if fn.get("name"):
                            slot["function"]["name"] += fn["name"]
                        if fn.get("arguments"):
                            slot["function"]["arguments"] += fn["arguments"]
                    if ch.get("finish_reason"):
                        finish = ch["finish_reason"]

        msg = {"role": "assistant", "content": "".join(content_parts) or None}
        rc = "".join(reasoning_parts)
        if rc:
            msg["reasoning_content"] = rc
        if tool_slots:
            msg["tool_calls"] = [tool_slots[i] for i in sorted(tool_slots)]
        if finish:
            msg["finish_reason"] = finish
        return msg


# -------------------------------------------------------------- tools ----
TOOLS_SCHEMA = [
    {"type": "function", "function": {
        "name": "bash",
        "description": "Run a shell command inside the working directory. "
                       "Use for builds, tests, git, ls, installing packages, etc.",
        "parameters": {"type": "object", "properties": {
            "command": {"type": "string", "description": "the shell command"}},
            "required": ["command"]}}},
    {"type": "function", "function": {
        "name": "read_file",
        "description": "Read a text file with line numbers (1-based). "
                       "Optionally restrict to a line range.",
        "parameters": {"type": "object", "properties": {
            "path": {"type": "string"},
            "start": {"type": "integer", "description": "first line (1-based, optional)"},
            "end": {"type": "integer", "description": "last line inclusive (optional)"}},
            "required": ["path"]}}},
    {"type": "function", "function": {
        "name": "write_file",
        "description": "Create or overwrite a file with the given content. "
                       "Parent directories are created automatically.",
        "parameters": {"type": "object", "properties": {
            "path": {"type": "string"}, "content": {"type": "string"}},
            "required": ["path", "content"]}}},
    {"type": "function", "function": {
        "name": "edit_file",
        "description": "Replace an exact unique string in a file. old_string must "
                       "appear exactly once — include enough surrounding context.",
        "parameters": {"type": "object", "properties": {
            "path": {"type": "string"},
            "old_string": {"type": "string"},
            "new_string": {"type": "string"}},
            "required": ["path", "old_string", "new_string"]}}},
    {"type": "function", "function": {
        "name": "list_dir",
        "description": "List the directory tree up to depth 2 (skips junk dirs).",
        "parameters": {"type": "object", "properties": {
            "path": {"type": "string", "description": "defaults to cwd"}}}}},
    {"type": "function", "function": {
        "name": "glob",
        "description": "Find files by glob pattern, e.g. '**/*.py'.",
        "parameters": {"type": "object", "properties": {
            "pattern": {"type": "string"}}, "required": ["pattern"]}}},
    {"type": "function", "function": {
        "name": "grep",
        "description": "Regex-search file contents under a directory. "
                       "Returns 'path:line: text' matches.",
        "parameters": {"type": "object", "properties": {
            "pattern": {"type": "string"},
            "path": {"type": "string", "description": "defaults to cwd"}},
            "required": ["pattern"]}}},
]


def _walk(root):
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames
                       if d not in IGNORE_DIRS and not d.startswith(".")]
        yield dirpath, dirnames, filenames


def tool_read_file(a, cwd):
    p = (Path(cwd) / a["path"]).resolve()
    text = p.read_text(encoding="utf-8", errors="replace")
    lines = text.splitlines()
    start = max(1, int(a.get("start") or 1))
    end = min(len(lines), int(a.get("end") or len(lines)))
    sel = lines[start - 1:end]
    out = [f"{i:>5}| {ln}" for i, ln in enumerate(sel, start=start)]
    if len(out) > 400:
        out = out[:400] + ["…[truncated]"]
    body = "\n".join(out) or "(empty file)"
    return True, clip(body, TO_MODEL_CAP)


def tool_write_file(a, cwd):
    p = (Path(cwd) / a["path"]).resolve()
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(a.get("content", ""), encoding="utf-8")
    return True, f"wrote {len(a.get('content', ''))} bytes -> {a['path']}"


def tool_edit_file(a, cwd):
    p = (Path(cwd) / a["path"]).resolve()
    text = p.read_text(encoding="utf-8", errors="replace")
    old, new = a["old_string"], a["new_string"]
    n = text.count(old)
    if n == 0:
        return False, "edit_file: old_string not found — read the file again and copy exact text."
    if n > 1:
        return False, f"edit_file: old_string matches {n} times — add surrounding context to make it unique."
    p.write_text(text.replace(old, new, 1), encoding="utf-8")
    return True, f"edited {a['path']} (1 replacement)"


def tool_bash(a, cwd):
    try:
        r = subprocess.run(a["command"], shell=True, cwd=cwd, text=True,
                           capture_output=True, timeout=120)
        out = f"exit={r.returncode}"
        if r.stdout.strip():
            out += "\nstdout:\n" + r.stdout.strip()
        if r.stderr.strip():
            out += "\nstderr:\n" + r.stderr.strip()
        return r.returncode == 0, clip(out, TO_MODEL_CAP)
    except subprocess.TimeoutExpired:
        return False, "bash: command timed out after 120s"


def tool_list_dir(a, cwd):
    root = (Path(cwd) / (a.get("path") or ".")).resolve()
    rows = []
    for dirpath, dirnames, filenames in _walk(root):
        rel = Path(dirpath).relative_to(root)
        depth = 0 if str(rel) == "." else len(rel.parts)
        indent = "  " * depth
        rows.append(f"{indent}{Path(dirpath).name if depth else '.'}/")
        for f in sorted(filenames)[:60]:
            rows.append(f"{indent}  {f}")
        if depth >= 1:
            dirnames[:] = []
        if len(rows) > 250:
            break
    return True, clip("\n".join(rows[:250]), TO_MODEL_CAP)


def tool_glob(a, cwd):
    hits = globmod.glob(str(Path(cwd) / a["pattern"]), recursive=True)
    rels = sorted(str(Path(h).relative_to(cwd)) for h in hits)[:200]
    return True, clip("\n".join(rels) or "(no matches)", TO_MODEL_CAP)


def tool_grep(a, cwd):
    root = (Path(cwd) / (a.get("path") or ".")).resolve()
    try:
        rx = re.compile(a["pattern"])
    except re.error as e:
        return False, f"grep: bad regex: {e}"
    hits = []
    for dirpath, _, filenames in _walk(root):
        for f in filenames:
            fp = Path(dirpath) / f
            try:
                if fp.stat().st_size > 2_000_000:
                    continue
                raw = fp.read_bytes()
                if b"\x00" in raw[:1024]:
                    continue
                for i, ln in enumerate(raw.decode("utf-8", "replace").splitlines(), 1):
                    if rx.search(ln):
                        rel = fp.relative_to(cwd)
                        hits.append(f"{rel}:{i}: {ln.strip()[:200]}")
                        if len(hits) >= 100:
                            break
            except OSError:
                continue
            if len(hits) >= 100:
                break
        if len(hits) >= 100:
            break
    return True, clip("\n".join(hits) or "(no matches)", TO_MODEL_CAP)


TOOL_IMPL = {
    "read_file": tool_read_file, "write_file": tool_write_file,
    "edit_file": tool_edit_file, "bash": tool_bash,
    "list_dir": tool_list_dir, "glob": tool_glob, "grep": tool_grep,
}
NEEDS_APPROVAL = {"bash", "write_file", "edit_file"}


# ---------------------------------------------------------- approval ----
class Approve:
    def __init__(self, yolo=False, print_mode=False):
        self.yolo = yolo
        self.print_mode = print_mode

    def ask(self, kind, detail):
        if self.yolo:
            return True
        if self.print_mode:
            print(f"{C.yellow}  [denied] {kind} needs approval — re-run with --yolo{C.reset}",
                  file=sys.stderr)
            return False
        try:
            while True:
                ans = input(f"{C.yellow}  allow {kind} {detail}? [y]es / [N]o / [a]lways "
                            f"{C.reset}").strip().lower()
                if ans in ("y", "yes"):
                    return True
                if ans in ("n", "no", ""):
                    return False
                if ans == "a":
                    self.yolo = True
                    return True
        except (EOFError, KeyboardInterrupt):
            print()
            return False


# ------------------------------------------------------- system prompt ----
def build_system(cwd):
    try:
        entries = sorted(os.listdir(cwd))[:40]
        listing = ", ".join(entries) or "(empty)"
    except OSError:
        listing = "(unreadable)"
    return (
        f"You are ncodex v{VERSION}, an interactive terminal coding agent "
        f"(in the spirit of OpenCode) running on the user's machine.\n"
        f"Environment: cwd={cwd} | platform={platform.system().lower()} "
        f"{platform.release()} | date={datetime.date.today().isoformat()}\n"
        f"Top-level entries: {listing}\n\n"
        "Rules:\n"
        "- You have tools: bash, read_file, write_file, edit_file, list_dir, glob, grep. "
        "Use them — do not guess file contents.\n"
        "- read files before editing them; prefer edit_file with a unique, "
        "context-rich old_string.\n"
        "- After code changes, verify with a quick bash run (tests, linters, running the app).\n"
        "- Paths are relative to the working directory. Never touch files outside it "
        "unless the user explicitly asks.\n"
        "- Keep answers concise and practical; summarise what you changed."
    )


# --------------------------------------------------------- agent loop ----
def run_agent(session, client, approver, max_iters=25):
    """One full agent turn: stream text, execute tool calls, feed results back."""
    for turn in range(1, max_iters + 1):
        print(f"{C.gray}── agent turn {turn} ──{C.reset}")
        sys.stdout.write(f"{C.magenta}●{C.reset} ")
        sys.stdout.flush()

        state = {"mode": "pending"}   # pending -> reasoning -> content

        def _clearline():
            sys.stdout.write("\r" + " " * 120 + "\r")

        def on_reasoning(t):
            if not session.show_reasoning:
                return
            if state["mode"] == "pending":
                _clearline()
                state["mode"] = "reasoning"
                sys.stdout.write(C.gray)
            if state["mode"] == "reasoning":
                sys.stdout.write(t)
                sys.stdout.flush()

        def on_content(t):
            if state["mode"] == "pending":
                _clearline()
                state["mode"] = "content"
            elif state["mode"] == "reasoning":
                state["mode"] = "content"
                sys.stdout.write(C.reset)
            sys.stdout.write(t)
            sys.stdout.flush()

        try:
            msg = client.chat(session.messages, TOOLS_SCHEMA,
                              on_content=on_content, on_reasoning=on_reasoning)
        except KeyboardInterrupt:
            sys.stdout.write(C.reset + "\n" + f"{C.red}^C — aborted turn{C.reset}\n")
            return
        sys.stdout.write(C.reset + "\n")

        session.messages.append(msg)
        calls = msg.get("tool_calls") or []
        if not calls:
            return

        for tc in calls:
            name = tc["function"]["name"].strip()
            raw = tc["function"].get("arguments") or "{}"
            try:
                args = json.loads(raw)
            except json.JSONDecodeError:
                args, ok, result = None, False, f"tool {name}: arguments were not valid JSON: {clip(raw, 200)}"
            if args is not None:
                impl = TOOL_IMPL.get(name)
                if impl is None:
                    ok, result = False, f"unknown tool: {name}"
                else:
                    summary = ", ".join(f"{k}={clip(str(v), 60)!r}" for k, v in list(args.items())[:2])
                    print(f"{C.cyan}  ⚙ {name}({summary}){C.reset}")
                    if name in NEEDS_APPROVAL and not approver.ask(name, summary):
                        ok, result = False, f"user denied the {name} call."
                    else:
                        try:
                            ok, result = impl(args, session.cwd)
                        except Exception as e:
                            ok, result = False, f"tool {name} crashed: {type(e).__name__}: {e}"
            print(f"  {'✓' if ok else C.red + '✗' + C.reset} {clip(result.splitlines()[-1] if result else '', 110)}")
            session.messages.append({"role": "tool", "tool_call_id": tc.get("id") or name,
                                     "content": result[:TO_MODEL_CAP]})
    print(f"{C.yellow}  (stopped after {max_iters} agent turns — /clear to reset){C.reset}")


# ------------------------------------------------------------ session ----
class Session:
    def __init__(self, cwd):
        self.cwd = cwd
        self.messages = []
        self.show_reasoning = True

    def reset(self):
        self.messages = [{"role": "system", "content": build_system(self.cwd)}]

    def ensure_system(self):
        if not self.messages:
            self.reset()


HELP = f"""
{C.bold}ncodex commands{C.reset}
  /help              this help
  /clear             fresh conversation (keeps cwd)
  /cd <path>         change working directory
  /cwd               show working directory
  /model [name]      show or set model (empty = server default)
  /models            list models from the server
  /yolo              toggle auto-approval of bash/writes
  /reasoning         toggle dimmed reasoning display
  /save              save transcript to ~/.ncodex/sessions/
  /system            show the current system prompt
  /exit  (or ^D)     save + quit
"""


def handle_command(line, session, client, approver, cfg):
    parts = line[1:].split(maxsplit=1)
    cmd, arg = parts[0].lower(), (parts[1].strip() if len(parts) > 1 else "")
    if cmd in ("exit", "quit", "q"):
        return "exit"
    if cmd == "help":
        print(HELP)
    elif cmd == "clear":
        session.reset()
        print(f"{C.gray}conversation cleared{C.reset}")
    elif cmd == "cd":
        target = Path(arg or Path.home()).expanduser()
        if not target.is_absolute():
            target = Path(session.cwd) / target
        if target.is_dir():
            session.cwd = str(target.resolve())
            session.reset()
            print(f"{C.gray}cwd -> {session.cwd} (context reset){C.reset}")
        else:
            print(f"{C.red}not a directory: {arg}{C.reset}")
    elif cmd == "cwd":
        print(session.cwd)
    elif cmd == "models":
        try:
            print(", ".join(client.models()))
        except ApiError as e:
            print(f"{C.red}{e}{C.reset}")
    elif cmd == "model":
        if arg:
            client.model = arg
            print(f"{C.gray}model -> {arg}{C.reset}")
        else:
            cur = client.model or "(server default)"
            print(f"current: {cur}   — set with /model <name>")
    elif cmd == "yolo":
        approver.yolo = not approver.yolo
        print(f"{C.gray}yolo {'ON — everything auto-approved' if approver.yolo else 'OFF'}{C.reset}")
    elif cmd == "reasoning":
        session.show_reasoning = not session.show_reasoning
        print(f"{C.gray}reasoning display {'ON' if session.show_reasoning else 'OFF'}{C.reset}")
    elif cmd == "system":
        session.ensure_system()
        print(f"{C.gray}{session.messages[0]['content']}{C.reset}")
    elif cmd == "save":
        SESSION_DIR.mkdir(parents=True, exist_ok=True)
        path = SESSION_DIR / f"{datetime.datetime.now():%Y%m%d-%H%M%S}.json"
        path.write_text(json.dumps({"cwd": session.cwd, "messages": session.messages},
                                   ensure_ascii=False, indent=1), encoding="utf-8")
        print(f"{C.gray}saved -> {path}{C.reset}")
    else:
        print(f"{C.gray}unknown command {cmd} — try /help{C.reset}")
    return None


# -------------------------------------------------------------- main ----
BANNER = rf"""{C.cyan}{C.bold}
   ███╗   ██╗ ██████╗ ██████╗ ██████╗ ███████╗██╗  ██╗
   ████╗  ██║██╔═══██╗██╔══██╗██╔══██╗██╔════╝╚██╗██╔╝
   ██╔██╗ ██║██║   ██║██║  ██║██║  ██║█████╗   ╚███╔╝
   ██║╚██╗██║██║   ██║██║  ██║██║  ██║██╔══╝   ██╔██╗
   ██║ ╚████║╚██████╔╝██████╔╝██████╔╝███████╗██╔╝ ██╗
   ╚═╝  ╚═══╝ ╚═════╝ ╚═════╝ ╚═════╝ ╚══════╝╚═╝  ╚═╝{C.reset}
{C.gray}   v{VERSION} — terminal coding agent → {DEFAULT_BASE}{C.reset}
{C.gray}   /help for commands · ^C interrupts · ^D exits{C.reset}
"""


def main():
    ap = argparse.ArgumentParser(prog="ncodex", description="OpenCode-style terminal coding agent")
    ap.add_argument("prompt", nargs="*", help="initial prompt (starts interactive mode if omitted with -i)")
    ap.add_argument("-p", "--print", dest="print_mode", action="store_true",
                    help="one-shot: print the final answer and exit")
    ap.add_argument("--base-url", default=DEFAULT_BASE, help="OpenAI-compatible API base URL")
    ap.add_argument("--key", default=os.environ.get("NCODEX_KEY"), help="API key (or env NCODEX_KEY)")
    ap.add_argument("--model", default=os.environ.get("NCODEX_MODEL") or None,
                    help="model id (default: server default)")
    ap.add_argument("--yolo", action="store_true", help="auto-approve bash/write/edit actions")
    ap.add_argument("--max-iters", type=int, default=25, help="agent tool-loop budget")
    ap.add_argument("--list-models", action="store_true", help="print models and exit")
    args = ap.parse_args()

    client = Client(args.base_url, args.key, args.model)
    approver = Approve(yolo=args.yolo, print_mode=args.print_mode)
    cwd = os.getcwd()
    session = Session(cwd)

    if args.list_models:
        try:
            for m in client.models():
                print(m)
        except ApiError as e:
            print(f"{C.red}{e}{C.reset}", file=sys.stderr)
            sys.exit(1)
        return

    session.ensure_system()

    if args.print_mode:
        prompt = " ".join(args.prompt).strip()
        if not prompt:
            ap.error("-p requires a prompt")
        session.messages.append({"role": "user", "content": prompt})
        try:
            run_agent(session, client, approver, args.max_iters)
        except ApiError as e:
            print(f"{C.red}{e}{C.reset}", file=sys.stderr)
            sys.exit(1)
        return

    print(BANNER)

    # seed the conversation with an initial prompt, then drop into the REPL
    if args.prompt and not args.print_mode:
        session.messages.append({"role": "user", "content": " ".join(args.prompt)})
        try:
            run_agent(session, client, approver, args.max_iters)
        except ApiError as e:
            print(f"{C.red}{e}{C.reset}")

    while True:
        try:
            line = input(f"{C.green}{C.bold}❯{C.reset} ")
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if not line.strip():
            continue
        if line.startswith("/"):
            if handle_command(line, session, client, approver, args) == "exit":
                break
            continue
        session.messages.append({"role": "user", "content": line})
        try:
            run_agent(session, client, approver, args.max_iters)
        except ApiError as e:
            print(f"\n{C.red}{e}{C.reset}")

    # auto-save transcript on exit
    try:
        if len(session.messages) > 1:
            SESSION_DIR.mkdir(parents=True, exist_ok=True)
            path = SESSION_DIR / f"{datetime.datetime.now():%Y%m%d-%H%M%S}.json"
            path.write_text(json.dumps({"cwd": session.cwd, "messages": session.messages},
                                       ensure_ascii=False, indent=1), encoding="utf-8")
            print(f"{C.gray}transcript -> {path}{C.reset}")
    except OSError:
        pass


# --------------------------------------------------------- readline ----
try:
    import readline
    READLINE = True
    if sys.stdin.isatty():
        try:
            readline.read_history_file(HISTORY_FILE)
        except OSError:
            pass
        readline.set_history_length(500)
        import atexit
        atexit.register(lambda: readline.write_history_file(HISTORY_FILE))
        _CMDS = ["/help", "/clear", "/cd ", "/cwd", "/model ", "/models",
                 "/yolo", "/reasoning", "/save", "/system", "/exit"]
        readline.parse_and_bind("tab: complete")

        def _complete(text, state):
            if not text.startswith("/"):
                return None
            matches = [c for c in _CMDS if c.startswith(text)]
            if state >= len(matches):
                return None
            return matches[state] + (" " if len(matches) == 1 else "")

        readline.set_completer(_complete)
except Exception:
    READLINE = False


if __name__ == "__main__":
    main()

