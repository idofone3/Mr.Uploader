# ncodex

OpenCode-style **terminal coding agent** for your DeepSeek wrapper.

Default endpoint: `https://deepu.niggahunter.qzz.io` (override with
`--base-url` — anything OpenAI-compatible works). **Stdlib only** — no
pip installs, just Python 3.8+.

## Quick start

```bash
cd your-project
bash install.sh          # optional: installs `ncodex` command (sudo not required)
ncodex                   # interactive agent
```

or with zero install:

```bash
python3 ncodex.py
```

## What it does

Streams answers from your deployed wrapper **and acts on your repo** through
an agent loop: the model can call tools, see their results, and keep going
until the task is done (up to 25 turns).

| Tool | Purpose |
| --- | --- |
| `bash` | run shell commands (build, test, git…) |
| `read_file` | read with line numbers, optional range |
| `write_file` | create / overwrite files |
| `edit_file` | exact unique string replace (safe: refuses ambiguous matches) |
| `list_dir` | depth-2 tree, junk dirs skipped |
| `glob` | find files like `**/*.py` |
| `grep` | regex search, `path:line: text` |

`bash` / `write_file` / `edit_file` ask for approval first:
`y` = once, `N` = skip, `a` = always (this session).

## Modes & flags

```bash
ncodex                              # interactive REPL
ncodex "fix the failing test"       # start with an initial prompt
ncodex -p "summarise this repo"     # one-shot print mode (script-friendly)
ncodex --yolo                       # auto-approve everything
ncodex --list-models                # print server models
ncodex --base-url http://127.0.0.1:8000   # local wrapper instead
ncodex --key KEY                    # if the server sets DS_API_KEY
ncodex --model deepseek             # pin a model
```

Env: `NCODEX_BASE`, `NCODEX_KEY`, `NCODEX_MODEL`.

## In-session commands

```
/help /clear /cd <path> /cwd /model [name] /models
/yolo /reasoning /save /system /exit
```

Tab completion + arrow-key history are enabled; transcripts auto-save to
`~/.ncodex/sessions/` on exit; input history lives in `~/.ncodex_history`.

## Notes

- Reasoning (DeepSeek thinking) streams dimmed; toggle with `/reasoning`.
- Tool output is capped at 8000 chars before going back to the model, so huge
  logs don't blow the context.
- `^C` interrupts the current agent turn; `^D` exits.
- Works against any OpenAI-compatible server with tool-calling support —
  point `--base-url` elsewhere anytime.
